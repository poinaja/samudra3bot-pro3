# -*- coding: utf-8 -*- 
#Sc Dri 
#Creator by samudra (Samudra__Bots)
from SAMUDRA import *
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from multiprocessing import Pool, Process
from datetime import datetime, timedelta
from time import sleep
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, html5lib, traceback, atexit
import urllib, urllib3
from humanfriendly import format_timespan, format_size, format_number, format_length
#from import Translator
from urllib.parse import urlencode
import requests.packages.urllib3.exceptions as urllib3_exceptions
from thrift import transport, protocol, server
#from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from threading import Thread
from multiprocessing import Pool, Process
from time import sleep
from bs4 import BeautifulSoup
from random import randint
from Naked.toolshed.shell import execute_js
from urllib.parse import urlencode
#=================================================================================#



#=================================================================================#
from random import randint

botStart = time.time()
print("""\033["""+str(randint(0,1))+""";"""+str(randint(31,36))+"""mBOT Samudra\nBy Samudra Bots\033[0m""")
#=================================================================================#



#=================================================================================#
from random import randint

botStart = time.time()
print("""\033["""+str(randint(0,1))+""";"""+str(randint(31,36))+"""mBOT Samudrabot\nBy Samudra\033[0m""")

samudra = LINE("token", appName="ANDROIDLITE\t2.14.0\tAndroid OS\t5.1.1")
samudra.log("Auth Token : " + str(samudra.authToken))

samudra1 = LINE("token", appName="ANDROIDLITE\t2.14.0\tAndroid OS\t5.1.1")
samudra1.log("Auth Token : " + str(samudra1.authToken))

samudrajs = LINE("token", appName="ANDROIDLITE\t2.14.0\tAndroid OS\t5.1.1")
samudrajs.log("Auth Token : " + str(samudrajs.authToken))
print ("SUKSES LOGIN DI SAMUDRA BOTS...!!!")

oepoll = OEPoll(samudra)
creator = ["midmu"]
owner = ["midmu"]
admin = ["Amid","Zmid","midmu"]
staff = ["midmu"]

samudraMID = samudra.getProfile().mid
samudra = samudra
lineProfile = samudra.getProfile()
mid = samudra.getProfile().mid
Amid = samudra1.getProfile().mid
Zmid = samudrajs.getProfile().mid

KAC = [samudra,samudra1]
ABC = [samudra1]
botlist = [samudra,samudra1,samudrajs]
JS = [samudrajs]
Bots = [mid,Amid,Zmid]

SAMUDRABOTS = admin + staff + owner

samudraMID = samudra.profile.mid
samudra1MID = samudra1.profile.mid
samudrajsMID = samudrajs.profile.mid
#------------------------------------------------------------------------------
samudraProfile = samudra.getProfile()
lineSettings = samudra.getSettings()
#------------------------------------------------------------------------------
samudra1Profile = samudra1.getProfile()
lineSettings = samudra1.getSettings()
#------------------------------------------------------------------------------
responsename1 = samudra1.getProfile().displayName
samudra1Name = samudra1.getProfile().displayName

proName = []
pro_name = []
protectjoin = []
proLink = []
proKick = []
proCancel = []
proInvite = []
ghostJs = []
unsendchat = {}
protectantijs = []
groupName = {}
groupImage = {}
wbanlist = []
welcome = []
msg_dict = {}
msg_dict1 = {}
settings = {
    "Picture":False,
    "videoProfile":False,
    "displayName":False,
    "coverId":False,
    "myProfile":False,
    "pictureStatus":False,
    "picture":False,
    "group":{},
    "changeCover":False,
    "changeVideo":False,
    "groupPicture":False,
    "changePicture":False,
    "autoJoinTicket":False,
#    "restartPoint": null,#
    "userMention":{},
    "autoJoin": True,
    "mimic": {},
    "target": {},
    "timeRestart": {},
    "server": {},
    "simiSimi":{},
    "rnameComand": {},
    "rname":{},
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "Limit": 1,
    "owner":{},
    "admin":{},
    "myProfile":{},
    "coverId":{},
    "keyCommand": "",
    "setKey": False,
    "undang":False,
    "changevid":False,
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "autoCancel": {
        "members": 1,
        "on": True
    },
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":False,
    "Js":True,
    "protect":True,
    "Kick":True,
    "Cancel":True,
    "Link":True,
    "contact":False,
    "invite":False,
    'autoJoin':True,
    'autoAdd':False,
    'autoBlock':False,
    'Timeline':False,
    'autoLeave':False,
    'autoLeave1':False,
    "detectMention":False,
    "mentionKick":False,
    "welcomeOn":False,
    "stickerOn":False,
    "likeOn":True,
    "chatbot": True,
    "tagall": "halo",
    "kikuk": "cubit",
    "cekUnsend": False,
    "limitinvite": False,
    "limitkick": False,
    "limitcancel": False,
    "AddstickerWelcome":{
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerLeave":{
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerSider":{
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerTag":{
        "sid": "",
        "spkg": "",
        "status":False
    },
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Videos":{},
    "Addaudio":{
            "name": "",
            "status":False
            },
    "Addvideo":{
            "name": "",
            "status":False
            },
    "unsend":False,
    "mention":"""
╭─• Sini kk kita ngerumpi >_<
""",
    "Respontag":"\nTag terus ampe keluar kupon >_<",
    "welcome":"""
➲ Welcome >_<
➲ Selamat bergabung..
➲ Cek note ya and salam kenal - _ -
""",
    "leave":"""
╭─• See You next time >_<
""",
    "comment":"""
    ❂▰▰▰▰♔ᴏᴘᴇɴ ᴏʀᴅᴇʀ♔▰▰▰▰❂
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
ꜱᴇʟғʙᴏᴛ ᴅᴀɴ ʙᴏᴛ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
➪ ѕεlƒвσт σиlч ρч3
➪ ѕεlƒвσт + αитι jѕ
➪ ѕεlƒвσт + 3 αѕιѕт
➪ ѕεlƒвσт + 5 αѕιѕт
➪ ѕεlƒвσт + 7 αѕιѕт
➪ ѕεlƒвσт + 10 αѕιѕт
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
ɴʙ﹕ ꜱᴇᴅɪᴀᴋᴀɴ ᴀᴋᴜɴ ʙᴏᴛ ꜱᴇɴᴅɪʀɪ 
ᴍɪɴᴀᴛ ᴘᴄ ʟᴀɴɢꜱᴜɴɢ 
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
            •Support' : Samudra__Bots 
                           Samudra
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
❂ вσт ρяσтεcт + αитι jѕ
❂ вσт ρяσтεcт σωиεя + αитι jѕ
❂ вσт ρяσтεcт яσσм ενεит
❂ вσт ρяσтεcт яσσм ѕмυlε
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
• Contact: https://line.me/ti/p/~samudrabots.py
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰ """,
    "message":"Thanks to for add me.....",
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('staff.json', 'r') as fp:
    staff = json.load(fp)


Setbot = codecs.open("setting.json","r","utf-8")
imagesOpen = codecs.open("image.json","r","utf-8")
videosOpen = codecs.open("video.json","r","utf-8")
stickersOpen = codecs.open("sticker.json","r","utf-8")
audiosOpen = codecs.open("audio.json","r","utf-8")
Setmain = json.load(Setbot)
images = json.load(imagesOpen)
videos = json.load(videosOpen)
stickers = json.load(stickersOpen)
audios = json.load(audiosOpen)

mulai = time.time()

def removeCmd(cmd, text):
	key = wait["keyCommand"]
	if wait["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]  


def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
   
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = client.genOBSParams({'oid': clientMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        client.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))

def Musik(to,msgf):
    contentMetadata={'previewUrl': "http://dl.profile.line-cdn.net/"+samudra.getContact(msgf).picturePath, 'i-installUrl': 'http://itunes.apple.com/app/linemusic/id966142320', 'type': 'mt', 'subText': samudra.getContact(msgf).statusMessage if samudra.getContact(msgf).statusMessage != '' else 'creator By Samudra |ID LINE|\samudrabots.py', 'a-installUrl': 'market://details?id=jp.linecorp.linemusic.android', 'a-packageName': 'jp.linecorp.linemusic.android', 'countryCode': 'JP', 'a-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'i-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'text': samudra.getContact(msgf).displayName, 'id': 'mt000000000d69e2db', 'linkUri': 'https://music.me.me/launch?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1','MSG_SENDER_ICON': "https://os.me.naver.jp/os/p/"+msgf,'MSG_SENDER_NAME':  samudra.getContact(msgf).displayName,}
    return samudra.sendMessage(to, samudra.getContact(msgf).displayName, contentMetadata, 19)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = client.genOBSParams({'oid': clientMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "update profile failed"
        client.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
 
def changeProfileVideo(to):
    if Setmain['changeProfileVideo']['picture'] == None:
        return client.sendMessage(to, "Foto tidak ditemukan")
    elif Setmain['changeProfileVideo']['video'] == None:
        return client.sendMessage(to, "Video tidak ditemukan")
    else:
        path = Setmaim['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = client.genOBSParams({'oid': client.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return client.sendMessage(to, "Gagal update profile")
        path_p = Setmain['changeProfileVideo']['picture']
        Setmain['changeProfileVideo']['status'] = False
        client.updateProfilePicture(path_p, 'vp')

def changetest(vids, picts):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = client.genOBSParams({'oid': clientMID, 'type': 'video', 'ver': '2.0', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return client.sendMessage(to, "Error")
        picture = picts
        client.updateProfilePicture(picture, 'vp')
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
           
def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = samudra.getGroup(to)
        textx = "「 Mentions Members 」\n\n1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "{}. ".format(str(no))
            else:
                textx += "\n「 Mentions {} Member 」".format(str(len(mid)))
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "Haii ".format(str(mid))
        arr = []
        no = 1
        num = 2
        for i in mid:
            #ginfo = samudra.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+settings["mention"]#+"\n "+str(ginfo.name)+"\n🤖     ᴀᴘᴋ-ʙᴏᴛs ᴀʟɪᴀɴsɪ    🤖"
            if no < len(mid):
                no += 1
                textx += " " % (num)
                num=(num+1)
            else:
                try:
                    no += "╚══[ {} ]".format(str(line.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))
          
def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "Eh ada ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Hallo ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = samudra.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+" Di "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "Selamat tinggal ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = samudra.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["leave"]
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        samudra.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendImage(to, path, name="image"):
    try:
        if setttings["server"] == "VPS":
            samudra.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)
                
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                samudra.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]
            
def command(text):
    pesan = text.lower()
    if Setmain["setKey"] == True:
        if pesan.startswith(Setmain["keyComand"]):
            cmd = pesan.replace(Setmain["keyComand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
    
def removeCmd(cmd, text):
	key = Setmain["rnameComand"]
	if Setmain["rname"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
	
def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

#message.createdTime -> 00:00:00
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log1():
    ndt = datetime.now()
    for data in msg_dict1:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict1[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict1[msg_id]

def atend1():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict1, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

#message.createdTime -> 00:00:00
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")


def helpkey():
    helpK =   "   ◀ Self Command ▶"+"\n"+\
                    " •───────────────•\n\n" + \
                    " • Adminset"+"\n"+\
                    " • Media"+"\n"+\
                    " • Setgroup"+"\n"+\
                    " • Protection"+"\n"+\
                    " • List pro"+"\n"+\
                    " • Kibar"+"\n"+\
                    " • Invite"+"\n"+\
                    " • Lagu"+"\n"+\
                    " • Joinbots"+"\n"+\
                    " • Joinqr"+"\n"+\
                    " • Outbots"+"\n"+\
                    " • Status self"+"\n"+\
                    " • Chatbot「on/off」\n" + \
                    " • Bot「on/off」\n" + \
                    " • Glist1-6"+"\n"+\
                    " • Glistjs1-2"+"\n"+\
                    " • 1-6open"+"\n"+\
                    " • Openjs1-2"+"\n"+\
                    " • Name-10:"+"\n"+\
                    " • Namejs-2:"+"\n"+\
                    " • Promo"+"\n"+\
                    " • 1-6ticket"+"\n"+\
                    " • 1-3invite"+"\n"+\
                    " • Addfriend"+"\n"+\
                    " • Jsaddbots"+"\n"+\
                    " • List friend\n" + \
                    " •───────────────•\n" + \
                    "「 By : Samudra  •\n • Samudra__Bots •\n"                    
    return helpK
                    
def helpadminset():
    helpK1 = "      ◀ Self Command ▶ \n" + \
                  " •───────────────•\n" + \
                  " • Status self\n" + \
                  " • Chatbot「on/off」\n" + \
                  " • List pro\n" + \
                  " • Me\n" + \
                  " • Mid「@」\n" + \
                  " • Steal「@」\n" + \
                  " • Cover「@」\n" + \
                  " • Invite \n" + \
                  " • Kill「@」\n" + \
                  " • Cubit「@」\n" + \
                  " • Clone「@」\n" + \
                  " • Call「@」\n" + \
                  " • Call「Jumlah」\n" + \
                  " • Naik「Jumlah」\n" + \
                  " • Restore\n" + \
                  " • Reject\n" + \
                  " • Mybot\n" + \
                  " • Cancelall\n" + \
                  " • Nukeall\n" + \
                  " • Restart\n" + \
                  " • Runtime\n" + \
                  " • Creator\n" + \
                  " • Speed/Sp\n" + \
                  " • Respontime\n" + \
                  " • Hai or Tagall\n" + \
                  " • Updatebot「foto」\n" + \
                  " • Botname:「Nama」\n" + \
                  " • groupid「Number」\n" + \
                  " • Ticket「Number」\n" + \
                  " • .pamit「Leave group」\n" + \
                  " • !leave「number gruplist」\n" + \
                  " • Leave「Namagrup」\n" + \
                  " • Ginfo\n" + \
                  " • Open\n" + \
                  " • Close\n" + \
                  " • Link \n" + \
                  " • Gruplist\n" + \
                  " • Open「Number」\n" + \
                  " • Close「Number」\n" + \
                  " • Infogrup「Number」\n" + \
                  " • Leaveall「Number」\n" + \
                  " • Remove chat\n" + \
                  " • Lurking「on/off」\n" + \
                  " • Lurkers\n" + \
                  " • Setkey「New Key」\n" + \
                  " • Mykey\n" + \
                  " • Resetkey\n" + \
                  " • Notag「on/off」\n" + \
                  " • Bot:on\n" + \
                  " • Bot:expell\n" + \
                  " • Staff:on\n" + \
                  " • Staff:expell\n" + \
                  " • Admin:on\n" + \
                  " • Admin:expell\n" + \
                  " • Botadd「@」\n" + \
                  " • Botdell「@」\n" + \
                  " • Staffadd「@」\n" + \
                  " • Staffdell「@」\n" + \
                  " • Adminadd「@」\n" + \
                  " • Admindell「@」\n" + \
                  " • Refresh\n" + \
                  " • List bot\n" + \
                  " • List staff\n" + \
                  " • ➥Next Key • MEDIA •\n" + \
                  " •───────────────•\n" + \
                  "「 By : Samudra  •\n • Samudra__Bots •\n"
                
                  
    return helpK1

def helpmedia():
    helpK2 = "    ◀ FITURE & MEDIA ▶ \n" + \
                  " •───────────────•\n" + \
                  " • Smuleaudio 「Link」\n" + \
                  " • Smulevideo 「Link」 \n" + \
                  " • Music「Judul Lagu」\n" + \
                  " • Joox「Judul Lagu」\n" + \
                  " • Lirik:「Judul Lagu」\n" + \
                  " • Addfriend @\n" + \
                  " • List friend\n" + \
                  " • Delfriend @\n" + \
                  " • Youtobemp3 「Text」\n" + \
                  " • Youtubevideo 「Text」\n" + \
                  " • Yvideo 「Text」\n" + \
                  " • Youtobe:「searching」\n" + \
                  " • Cinemaxx1「Text」\n" + \
                  " • Xxxcinema「Text」\n" + \
                  " • Arti_nama:「Text」\n" + \
                  " • .fs「Text」\n" + \
                  " • Textimage「Text」\n" + \
                  " • Calender\n" + \
                  " • Gift\n" + \
                  " • Listmp3\n" + \
                  " • Listvideo\n" + \
                  " • Listimage\n" + \
                  " • Liststicker\n" + \
                  " • Addimg「Teks」\n" + \
                  " • Dellimg「Teks」\n" + \
                  " • Addmp3「Teks」\n" + \
                  " • Dellmp3「Teks」\n" + \
                  " • Addvideo「Teks」\n" + \
                  " • Dellvideo「Teks」\n" + \
                  " • Addsticker「Teks」\n" + \
                  " • Dellsticker「Teks」\n" + \
                  " • Bc:「Text」\n" + \
                  " • Textimage「Text」\n" + \
                  " • Updatefoto 「Photo」\n" + \
                  " • Dualprofile 「Link Youtube」\n" + \
                  " • Updategrup\n" + \
                  " • Restore\n" + \
                  " •───────────────•\n" + \
                  "    ◀ KAMUS BAHASA▶ \n" + \
                  " •───────────────•\n" + \
                  " • Eng:「Text」\n" + \
                  " • Jp:「Text」\n" + \
                  " • Thai:「Text」\n" + \
                  " • Korea:「Text」\n" + \
                  " • Arab:「Text」\n" + \
                  " • Jawa:「Text」\n" + \
                  " • Indo:「Query」\n\n" + \
                  " • ➥Next Key[ Setgroup ]\n\n" + \
                  " •───────────────•\n" + \
                  "「 By : Samudra  •\n • Samudra__Bots •\n"                 
    return helpK2
    
def helpsetgroup():
    helpK3 = "      ◀  SETTING SELF▶ \n" + \
                  " •───────────────•\n" + \
                  " • Sticker welcome\n" + \
                  " • Sticker leave\n" + \
                  " • Sticker sider\n" + \
                  " • Sticker tag\n" + \
                  " • Cek coment post\n" + \
                  " • Cek mention\n" + \
                  " • Cek sider\n" + \
                  " • Cek spam\n" + \
                  " • Cek pesan \n" + \
                  " • Cek respon \n" + \
                  " • Cek leave\n" + \
                  " • Cek welcome\n" + \
                  " • Set mention:「Text」\n" + \
                  " • Set sider:「Text」\n" + \
                  " • Set spam:「Text」\n" + \
                  " • Set pesan:「Text」\n" + \
                  " • Set respon:「Text」\n" + \
                  " • Set leave:「Text」\n" + \
                  " • Set welcome:「Text」\n" + \
                  " • Set coment:「Text」\n" + \
                  " • Name:「Nama」\n" + \
                  " •─「 SET ON & OFF 」─•\n" + \
                  " • Sider「on/off」\n" + \
                  " • Invite「on/off」\n" + \
                  " • Sticker「on/off」\n" + \
                  " • Respon「on/off」\n" + \
                  " • Timeline「on/off」\n" + \
                  " • Contact「on/off」\n" + \
                  " • Autojoin「on/off」\n" + \
                  " • Autoadd「on/off」\n" + \
                  " • Autolike「on/off」\n" + \
                  " • Autoblock「on/off」\n" + \
                  " • Welcome「on/off」\n" + \
                  " • Autoleave「on/off」\n" + \
                  " • Jointicket「on/off」\n\n" + \
                  " •➥Next Key [ Protection ]\n" + \
                  " •───────────────•\n" + \
                  "「 By : Samudra  •\n • Samudra__Bots •\n"
    return helpK3
    
def helpprotection():
    helpK4 ="       ◀ PROTECTION ▶ \n" + \
                  " •───────────────•\n\n" + \
                  " • Projs  「 on/off 」\n" + \
                  " • Prolink  「 on/off 」\n" + \
                  " • Projoin 「 on/off 」\n" + \
                  " • Prokick 「 on/off 」\n" + \
                  " • Proinvite 「 on/off 」\n" + \
                  " • Procancel 「 on/off 」\n" + \
                  " • Proname 「 on/off 」\n" + \
                  " • Iconlock 「 on/off 」\n" + \
                  " • Pro:all on\n" + \
                  " • Hard: 「 on/off 」\n" + \
                  " • Addwordban「 Text 」\n" + \
                  " • Delwordban: 「 Text 」\n" + \
                  " • List wordban\n" + \
                  " • List pro「Daftar Protect」\n\n" + \
                  " •───────────────•\n" + \
                  "「 By : Samudra  •\n • Samudra__Bots •\n"
    return helpK4



def attck(grup, target):
    try:
        samudra1.kickoutFromGroup(grup, [target])
    except:
        try:
            samudrajs.kickoutFromGroup(grup, [target])
        except:
            pass                                                    
    print("KICKERS ATTAK")

def cancl(grup, target):
    try:
        samudra1.cancelGroupInvitation(grup, [target])
    except:
        pass                                                
    print("Kickers Cancel")

def backp(grup, target):
    try:
        samudra1.inviteIntoGroup(grup, [mid,Bmid,Zmid])
        samudra.acceptGroupInvitation(grup)
    except:
        try:
            samudra.inviteIntoGroup(grup, [mid,Amid,Zmid])
            samudra1.acceptGroupInvitation(grup)
        except:
            pass                                                    
    print("KICKERS BACKUP")
def lockqr(grup):
    G = samudra.getGroup(grup)
    G.preventedJoinByTicket = True
    try:
        samudra.updateGroup(G)
    except:
        try:
            samudra1.updateGroup(G)
        except:
            pass

def lockqr1(grup):
    G = random.choice(ABC).getGroup(grup)
    G.preventedJoinByTicket = True
    try:
        samudra.updateGroup(G)
    except:
        try:
            samudra1.updateGroup(G)
        except:
            pass

def black(target):
    if target not in wait["blacklist"]:
        wait["blacklist"][target] = True

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
#==================[PROTECT QR]===================        
        if op.type == 25 or op.type == 26:
          if wait['undang'] == True:
            msg = op.message
            user = msg._from
            kirim = msg.to    	
            if msg.contentType == 13:
                #if wait["Admin"]:
                    _name = msg.contentMetadata["displayName"]
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(kirim)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            samudra.sendMessage(msg.to, _name + " Sudah hadir dalam grup")
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                samudra.findAndAddContactsByMid(target)
                                samudra.inviteIntoGroup(kirim,[target])
                                samudra.samudra(msg.to,"undang " + _name + "\nSUCCESS..")
                                wait['undang'] = False
                                break
                            except:             
                                 samudra.sendMessage(msg.to, 'Sukse Bos')
                                 wait['undang'] = False
                                 break

        if op.type == 25 or op.type == 26:
          if wait['undang'] == True:
            msg = op.message
            user = msg._from
            kirim = msg.to    	
            if msg.contentType == 13:
                #if wait["Admin"]:
                    _name = msg.contentMetadata["displayName"]
                    invite = msg.contentMetadata["mid"]
                    groups = samudra1.getGroup(kirim)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            samudra1.sendMessage(msg.to, _name + " Sudah hadir dalam grup")
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                samudra1.findAndAddContactsByMid(target)
                                samudra1.inviteIntoGroup(kirim,[target])
                                samudra1.samudra1(msg.to,"undang " + _name + "\nSUCCESS..")
                                wait['undang'] = False
                                break
                            except:             
                                 samudra1.sendMessage(msg.to, 'Sukse Bos')
                                 wait['undang'] = False
                                 break


        if op.type == 11:
            if op.param1 in proLink:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == True:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            samudra.reissueGroupTicket(op.param1)
                            X = samudra.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            samudra.updateGroup(X)
                            samudra.kickoutFromGroup(op.param1,[op.param2])
                            samudra.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:
                    try:
                        if samudra1.getGroup(op.param1).preventedJoinByTicket == True:
                            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                samudra1.reissueGroupTicket(op.param1)
                                X = samudra1.getGroup(op.param1)
                                X.preventedJoinByTicket = True
                                samudra1.updateGroup(X)
                                samudra1.kickoutFromGroup(op.param1,[op.param2])
                                samudra1.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                    except:
                        pass                                           # pass
#==================[BLACKLIST QR]=================== 
        if op.type == 11:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t = Thread(target=attck, args=(op.param1, op.param2))
                    t.start()
                    t1 = Thread(target=lockqr, args=(op.param1,))
                    t1.start()
                    t2 = Thread(target=lockqr1, args=(op.param1,))
                    t2.start()
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t3 = Thread(target=attck, args=(op.param1, op.param2))
                    t3.start()
                    t4 = Thread(target=lockqr, args=(op.param1,))
                    t4.start() 
                    t5 = Thread(target=lockqr1, args=(op.param1,))
                    t5.start()
            if op.param1 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t6 = Thread(target=attck, args=(op.param1, op.param2))
                    t6.start()
                    t7 = Thread(target=lockqr, args=(op.param1,))
                    t7.start() 
                    t8 = Thread(target=lockqr1, args=(op.param1,))
                    t8.start()  
#==================[AUTO JOIN CANCELL]===================                                



        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        samudra.acceptGroupInvitation(op.param1)
                    else:
                        samudra.acceptGroupInvitation(op.param1)

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        samudra1.acceptGroupInvitation(op.param1)
                    else:
                        samudra1.acceptGroupInvitation(op.param1)                        #ki10.acceptGroupInvitation(op.param1)

            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots:
                    t9 = Thread(target=attck, args=(op.param1, op.param2))
                    t9.start()
                    t10 = Thread(target=cancl, args=(op.param1, op.param3))
                    t10.start()
                    t11 = Thread(target=black, args=(op.param2,))
                    t11.start()
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots:
                    t12 = Thread(target=attck, args=(op.param1, op.param2))
                    t12.start()
                    t13 = Thread(target=cancl, args=(op.param1, op.param3))
                    t13.start()
                    t14 = Thread(target=black, args=(op.param2,))
                    t14.start()                  #  t14.start()
#==================[AUTO LEAVE]===================                                
        if op.type == 19:
            try:
                if op.param1 in protectantijs:
                  if op.param3 in mid:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        wait["blacklist"][op.param2] = True
                        G = random.choice(ABC).getGroup(grup)
                        G.preventedJoinByTicket = False
                        samudra.updateGroup(G)
                        Ticket = random.choice(ABC).reissueGroupTicket(grup)
                        samudrajs.acceptGroupInvitation(op.param1)
                        samudrajs.kickoutFromGroup(op.param1,[op.param2])
                        G = samudrajs.getGroup(grup)
                        G.preventedJoinByTicket = False
                        samudrajs.updateGroup(G)
                        Ticket = samudrajs.reissueGroupTicket(grup)
                        samudra.acceptGroupInvitationByTicket(grup,Ticket)
                        samudra1.acceptGroupInvitationByTicket(grup,Ticket)
                        samudrajs.leaveGroup(op.param1)
                        random.choice(KAC).inviteIntoGroup(op.param1,[Zmid])
                        samudra.inviteIntoGroup(op.param1,[admin])
                        G.preventedJoinByTicket = True
                        random.choice(ABC).kickoutFromGroup(grup, [target])
                        Ticket = random.choice(ABC).reissueGroupTicket(grup)
                    else:
                        pass
                        
           
                if op.param3 in Zmid:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        random.choice(KAC).findAndAddContactsByMid(op.param3)
                        samudra1.inviteIntoGroup(op.param1,[Zmid])
                        samudra.sendMessage(op.param1,"=AntiJS Invited=")
                    else:
                        samudra.kickoutFromGroup(op.param1,[op.param2])
                        samudra.findAndAddContactsByMid(op.param3)
                        samudra.inviteIntoGroup(op.param1,[Zmid])
                        samudra.sendMessage(op.param1,"=AntiJS Invited=")
                        
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if op.param3 in admin:
                        if op.param1 in protectantijs:
                            wait["blacklist"][op.param2] = True
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            samudra.findAndAddContactsByMid(op.param3)
                            samudra.inviteIntoGroup(op.param1,[op.param3])
                            samudra.sendMessage(op.param1,"=Admin Invited=")
                else:
                    pass
            except:
                pass

            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        samudra.acceptGroupInvitation(op.param1)
                        ginfo = samudra.getGroup(op.param1)
                        samudra.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        samudra.leaveGroup(op.param1)
                    else:
                        samudra.acceptGroupInvitation(op.param1)
                        ginfo = samudra.getGroup(op.param1)
                        #samudra.sendMessage(op.param1," " + str(ginfo.name))
#==================[PROTECT INVITE]===================                                
        if op.type == 13:
            if op.param1 in proInvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = samudra.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            samudra.cancelGroupInvitation(op.param1,[op.param3])
                            samudra.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            group = samudra.getGroup(op.param1)
                            gMembMids = [contact.mid for contact in group.invitee]
                            for _mid in gMembMids:
                                samudra1.cancelGroupInvitation(op.param1,[op.param3])
                                samudra1.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            pass
#==================[WELCOME & LEAVE]===================                                
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = samudra.getGroup(op.param1)
                contact = samudra.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                samudra.sendImageWithURL(op.param1, image)

        if op.type == 15:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = samudra.getGroup(op.param1)
                contact = samudra.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                leaveMembers(op.param1, [op.param2])
                samudra.sendImageWithURL(op.param1, image)
#==================[BLACKLIST JOIN PURGE]===================    
        if op.type == 17: #JOIN
            if op.param2 in wait["blacklist"]:
                t15 = Thread(target=attck, args=(op.param1, op.param2))
                t15.start()
                t16 = Thread(target=attck, args=(op.param1, op.param2))
                t16.start()
            if op.param1 in wait["blacklist"]:
                t17 = Thread(target=attck, args=(op.param1, op.param2))
                t17.start()
                t18 = Thread(target=attck, args=(op.param1, op.param2))
                t18.start()
#==================[PROTECT JOIN]===================                                                            
        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            if op.param3 not in wait["blacklist"]:
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                if op.param3 not in wait["blacklist"]:
                                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    if op.param3 not in wait["blacklist"]:
                                        random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    pass
                return
#=============================================                                                            
        if op.type == 0:
            return
        if op.type == 5:
              if wait["autoAdd"] == True:
                  cl.findAndAddContactsByMid(op.param1)
                  sendMention(op.param1, op.param1, "Hai kak ", ", ")
                  cl.sendMessage(op.param1, wait["message"])

        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if wait["autoBlock"] == False:
                #samudra.blockContact(op.param1)
                samudra.sendMessage(op.param1,"╭───────────────\n│╭──────────────\n│├• ᴛᴇʀɪᴍᴀᴋᴀsɪʜ\n│├• sᴀмuᴅʀᴀ\n│╰──────────────\n├──•〔 ᴏ ᴘ ᴇ ɴ ʀ ᴇ ɴ ᴛ ᴀ ʟ 〕\n│╭──────────────\n│├─•  sᴇʟғʙᴏᴛ :\n││( 𝟏 )• ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n││( 𝟐 )• ɴᴏ ᴛᴇᴍᴘʟᴀᴛᴇ\n│├─•  ᴘʀᴏᴛᴇᴄᴛ / ᴡᴀʀ :\n││( 𝟏 )• 𝟑 ᴀssɪsᴛ\n││( 𝟐 )• 𝟓 ᴀssɪsᴛ\n││( 𝟑 )• 𝟕 ᴀssɪsᴛ\n││( 𝟒 )• ᴄʟɪᴇɴᴛ ᴘʀᴏᴛᴇᴄᴛ\n│╰──────────────\n├──•〔 sᴇʟʟ   ᴛʜᴇ   sᴄʀɪᴘᴛ 〕\n│╭──────────────\n││( 𝟏 )• ʜᴇʟᴘᴇʀs\n││( 𝟐 )• sʙ ᴡᴀʀ\n││( 𝟑 )• sʙ ᴘʀᴏᴛᴇᴄᴛ\n││( 𝟒 )• ᴄʟ/ᴄʟɪᴇɴᴛ\n││( 𝟓 )• sʙ ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n│╰──────────────\n│ ན ᴄʀ : line://ti/p/~samudrabots.py\n│ ན ᴄʀ : line://ti/p/~samudrabots.py\n╰───────────────")

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = samudra.getGroup(at)
                                ryan = samudra.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "╭─「 Gambar Dihapus 」\n│ Pengirim : "
                                ret_ = "│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                samudra.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                samudra.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = samudra.getGroup(at)
                                ryan = samudra.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "╭─「 Pesan Dihapus 」\n"
                                ret_ += "│ Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n│ Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                ret_ += "\n╰───────────"
                                samudra.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = samudra.getGroup(at)
                                ryan = samudra.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╭─「 Sticker Dihapus 」\n"
                                ret_ += "│ Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                ret_ += "\n╰───────────"
                                samudra.sendMessage(at, str(ret_))
                                samudra.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
#=================[BACKUPS SAMUDRA BOTS]=================    
        if op.type == 19:
            if op.param3 in owner:
                    if op.param2 in owner:
                        pass
                    if op.param2 in admin:
                        pass
                    if op.param2 in staff:
                        pass
                    if op.param2 in Bots:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        try:
                            samudrajs.acceptGroupInvitation(op.param1)
                            random.choice(JS).kickoutFromGroup(op.param1,[op.param2])
                            samudrajs.findAndAddContactsByMid(op.param3)
                            samudrajs.inviteIntoGroup(op.param1,[mid,Amid])
                            samudra.acceptGroupInvitation(op.param1)
                            samudra1.acceptGroupInvitation(op.param1)
                            samudrajs.leaveGroup(op.param1)
                            random.choice(KAC).inviteIntoGroup(op.param1,[Zmid])
                        except:
                            pass
                            
            if op.param3 in admin:
                    if op.param2 not in owner:
                        pass
                    if op.param2 not in admin:
                        pass
                    if op.param2 not in staff:
                        pass
                    if op.param2 not in Bots:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        try:
                            samudrajs.acceptGroupInvitation(op.param1)
                            random.choice(JS).kickoutFromGroup(op.param1,[op.param2])
                            samudrajs.findAndAddContactsByMid(op.param3)
                            random.choice(JS).inviteIntoGroup(op.param1,[op.param3])
                            samudra.acceptGroupInvitation(op.param1)
                            samudrajs.leaveGroup(op.param1)
                            random.choice(KAC).inviteIntoGroup(op.param1,[Zmid])
                        except:
                            pass       
                                    
        if op.type == 19:
            if mid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t19 = Thread(target=attck, args=(op.param1, op.param2))
                    t19.start()
                    t20 = Thread(target=black, args=(op.param2,))
                    t20.start()
                    t21 = Thread(target=backp, args=(op.param1, op.param3))
                    t21.start()
                return
            if Amid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    t22 = Thread(target=attck, args=(op.param1, op.param2))
                    t22.start()
                    t23 = Thread(target=black, args=(op.param2,))
                    t23.start()
                    t24 = Thread(target=backp, args=(op.param1, op.param3))
                    t24.start()
                return
#========================[BACKUP OWNER ADMIN & STAFF]=====================    

        if op.type == 19:
            if op.param3 in owner:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            samudra.kickoutFromGroup(op.param1,[op.param2])
                            samudra.findAndAddContactsByMid(jack)
                            samudra.inviteIntoGroup(op.param1,[jack])
                        except:
                            try:
                                samudra1.kickoutFromGroup(op.param1,[op.param2])
                                samudra1.findAndAddContactsByMid(jack)
                                samudra1.inviteIntoGroup(op.param1,[jack])
                            except:
                                pass
            if op.param3 in admin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            samudra.kickoutFromGroup(op.param1,[op.param2])
                            samudra.findAndAddContactsByMid(jack)
                            samudra.inviteIntoGroup(op.param1,[jack])
                        except:
                            try:
                                samudra1.kickoutFromGroup(op.param1,[op.param2])
                                samudra1.findAndAddContactsByMid(jack)
                                samudra1.inviteIntoGroup(op.param1,[jack])
                            except:
                                pass

            if op.param3 in staff:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            samudra.kickoutFromGroup(op.param1,[op.param2])
                            samudra.findAndAddContactsByMid(jack)
                            samudra.inviteIntoGroup(op.param1,[jack])
                        except:
                            try:
                                samudra1.kickoutFromGroup(op.param1,[op.param2])
                                samudra1.findAndAddContactsByMid(jack)
                                samudra1.inviteIntoGroup(op.param1,[jack])
                            except:
                                pass                                                                
#========================[PROTECT KICK]=====================                                                            
        if op.type == 19:
            if op.param1 in proKick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            samudra.kickoutFromGroup(op.param1,[op.param2])
                            samudra.findAndAddContactsByMid(jack)
                            sdmudra.inviteIntoGroup(op.param1,[jack])
                        except:
                            try:
                                samudra1.kickoutFromGroup(op.param1,[op.param2])
                                samudra1.findAndAddContactsByMid(jack)
                                samudra1.inviteIntoGroup(op.param1,[jack])
                            except:
                                pass

        if op.type == 19:
            if op.param1 in wait["Js"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            samudrajs.acceptGroupInvitation(op.param1)
                            samudrajs.kickoutFromGroup(op.param1,[op.param2])
                            samudrajs.findAndAddContactsByMid(op.param3)
                            samudrajs.inviteIntoGroup(op.param1,[mid,Amid])
                            samudra.acceptGroupInvitation(op.param1)
                            samudra1.acceptGroupInvitation(op.param1)
                            samudrajs.leaveGroup(op.param1)
                            random.choice(KAC).inviteIntoGroup(op.param1,[Zmid])
                        except:
                            pass

        if op.type == 19:
            if op.param1 in wait["Kick"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for jack in ownX:
                        try:
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(ABC).findAndAddContactsByMid(jack)
                            random.choice(ABC).inviteIntoGroup(op.param1,[jack])
                        except:
                            pass

        if op.type == 32:
            if op.param1 in wait["Cancel"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(ABC).inviteIntoGroup(msg.to, [Zmid,Z2mid])
                    except:
                        pass

        if op.type == 11:
            if op.param1 in wait["Link"] == True:
                try:
                    if samudra.getGroup(op.param1).preventedJoinByTicket == True:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            random.choice(ABC).reissueGroupTicket(op.param1)
                            X = random.choice(ABC).getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            randon.choice(ABC).updateGroup(X)
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass

#======================[PROTECT CANCEL]=======================                                                            
        
        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    pass
                else:
                    try:
                        if op.param3 not in wait["blacklist"]:
                            settings["blacklist"][op.param2] = True
                            if op.param3 not in settings["blacklist"]:
                                try:
                                    samudra1.kickoutFromGroup(op.param1,[op.param2])
                                    samudra1.findAndAddContactsByMid(op.param3)
                                    samudra1.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    pass
                            else:pass
                        else:pass
                    except:
                        pass


                
#_________________________PRO CANCEL GHOST JS ______________________#
        if op.type == 32:
            if op.param1 in ghostJs:
              if op.param3 in Zmid:    
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    f=codecs.open('protect.json','w','utf-8')
                    json.dump(Memek, f, sort_keys=True, indent=4,ensure_ascii=False)
                    samudra.sendMessage(op.param1, " ➥ Don't Cancelled Mybots...")
                    try:
                        if op.param3 not in wait["blacklist"]:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[Zmid])
                    except:
                        pass
#======================[BLACKLIST READ]=======================                                      
#======================[BLACKLIST READ]=======================                                      
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                t52 = Thread(target=attck, args=(op.param1, op.param2))
                t52.start()      
            if op.param1 in wait["blacklist"]:
                t53 = Thread(target=attck, args=(op.param1, op.param2))
                t53.start()        
        
            if op.param1 in Setmain["readPoint"]:
                if op.param2 in Setmain["readMember"][op.param1]:
                    pass
                else:
                    Setmain["readMember"][op.param1][op.param2] = True
            else:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = samudra.getContact(op.param2).displayName
                    Np = samudra.getContact(op.param2).pictureStatus
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        samudra.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net/" + Np)
                        sid = str(wait["AddstickerSider"]["sid"])
                        spkg = str(wait["AddstickerSider"]["spkg"])
                        samudra.sendSticker(op.param1, spkg, sid)

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                          except:
                              random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
               if 'MENTION' in msg.contentMetadata.keys() != None:
                if msg._from not in Bots:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']                   
                   for mention in mentionees:
                        if mention ['M'] in admin:
                           contact = samudra.getContact(msg._from)
                           anu = contact.displayName
                           samudra.sendMessage(msg.to, "."+anu+"\n"+wait["Respontag"])
                           sid = str(wait["AddstickerTag"]["sid"])
                           spkg = str(wait["AddstickerTag"]["spkg"])
                           samudra.sendSticker(msg.to, spkg, sid)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                if msg._from not in Bots:
                 if wait["mentionKick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in admin:
                           samudra.sendMessage(msg.to, "Jangan tag saya ogeb")
                           samudra.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["stickerOn"] == True:
                    msg.contentType = 0
                    samudra.sendMessage(msg.to,"╭─「 Cek ID Sticker 」\n├↘ STKID : " + msg.contentMetadata["STKID"] + "\n├↘ STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n├↘ STKVER : " + msg.contentMetadata["STKVER"]+ "\n├↘\n╰─「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    samudra.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = samudra.getContact(msg.contentMetadata["mid"])
                        path = samudra.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        samudra.sendMessage(msg.to,"╭─「 Contact Info 」\n├↘ Nama : " + msg.contentMetadata["displayName"] + "\n├↘ MID : " + msg.contentMetadata["mid"] + "\n├↘ Status Msg : " + contact.statusMessage + "\n├↘ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        samudra.sendImageWithURL(msg.to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            stickername = str(text)
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 16:
                    if wait["Timeline"] == True:
                            ret_ = "「 Detail Postingan 」"
                            if msg.contentMetadata["serviceType"] == "GB":
                                contact = cl.getContact(sender)
                                auth = "\n• Penulis : {}".format(str(contact.displayName))
                            else:
                                auth = "\n• Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                            ret_ += auth
                            if "stickerId" in msg.contentMetadata:
                                stck = "\n• Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                ret_ += stck
                            if "mediaOid" in msg.contentMetadata:
                                object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                if msg.contentMetadata["mediaType"] == "V":
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                    ret_ += murl
                                else:
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                ret_ += ourl
                            if "text" in msg.contentMetadata:
                                text = "\n• Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                purl = "\n• Post URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += purl
                                ret_ += text
                            samudra.sendMessage(to, str(ret_))
               if msg.contentType == 16:
                if wait["likeOn"] == True:
                    url = msg.contentMetadata["postEndUrl"]
                    daftarLike = [1001,1002,1003,1004,1005,1006]
                    likeType = random.choice(daftarLike)
                    samudra.like(url[25:58], url[66:], likeType=1006)
                    samudra1.like(url[25:58], url[66:], likeType=1006)
                    samudra.comment(url[25:58], url[66:], wait["comment"])      
                    samudra1.comment(url[25:58], url[66:], wait["comment"])      
                    
               if msg.contentType == 7:
                 if msg._from in creator or msg._from in owner or msg._from in admin:
                    if wait["AddstickerTag"]["status"] == True:
                        wait["AddstickerTag"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerTag"]["spkg"] = msg.contentMetadata['STKPKGID']
                        samudra.sendMessage(msg.to, "Succses merubah sticker respon 🎵")
                        wait["AddstickerTag"]["status"] = False     
               if msg.contentType == 7:
                 if msg._from in creator or msg._from in owner or msg._from in admin:
                    if wait["AddstickerSider"]["status"] == True:
                        wait["AddstickerSider"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerSider"]["spkg"] = msg.contentMetadata['STKPKGID']
                        samudra.sendMessage(msg.to, "sukses menambahkan sticker sider 🎵")
                        wait["AddstickerSider"]["status"] = False
               if msg.contentType == 7:
                 if msg._from in creator or msg._from in owner or msg._from in admin:
                    if wait["AddstickerWelcome"]["status"] == True:
                        wait["AddstickerWelcome"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerWelcome"]["spkg"] = msg.contentMetadata['STKPKGID']
                        samudra.sendMessage(msg.to, "Succses merubah sticker welccome 🎵")
                        wait["AddstickerWelcome"]["status"] = False     
               if msg.contentType == 7:
                 if msg._from in creator or msg._from in owner or msg._from in admin:
                    if wait["AddstickerLeave"]["status"] == True:
                        wait["AddstickerLeave"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerLeave"]["spkg"] = msg.contentMetadata['STKPKGID']
                        samudra.sendMessage(msg.to, "sukses menambahkan leave 🎵")
                        wait["AddstickerLeave"]["status"] = False                   
                       
               if msg.contentType == 0:
                    msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
               if msg.text:
                    if msg.text.lower().lstrip().rstrip() in wbanlist:
                        if msg.text not in clientMID:
                            try:
                                samudra.kickoutFromGroup(msg.to,[sender])
                            except Exception as e:
                                 print(e)
               if msg.contentType == 1:
                    path = samudra.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
               if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n\n「 Sticker Info 」"
                   ret_ += "\n➪ Sticker ID : {}".format(stk_id)
                   ret_ += "\n➪ Sticker Version : {}".format(stk_ver)
                   ret_ += "\n➪ Sticker Package : {}".format(pkg_id)
                   ret_ += "\n➪ Sticker Url : line://shop/detail/{}".format(pkg_id)
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = samudra.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
               if msg.contentType == 7:
                if wait["stickerOn"] == True:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    with requests.session() as s:
                        s.headers['user-agent'] = 'Mozilla/5.0'
                        r = s.get("https://store.line.me/stickershop/product/{}/id".format(urllib.parse.quote(pkg_id)))
                        soup = BeautifulSoup(r.content, 'html5lib')
                        data = soup.select("[class~=mdBtn01Txt]")[0].text
                        if data == 'Lihat Produk Lain':
                            ret_ = "「 Sticker Info 」"
                            ret_ += "\n~STICKER ID : {}".format(stk_id)
                            ret_ += "\n~STICKER PACKAGES ID : {}".format(pkg_id)
                            ret_ += "\n~STICKER VERSION : {}".format(stk_ver)
                            ret_ += "\n~STICKER URL : line://shop/detail/{}".format(pkg_id)
                            samudra.sendMessage(msg.to, str(ret_))
                            query = int(stk_id)
                            if type(query) == int:
                               data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                               path = samudra.downloadFileURL(data)
                               samudra.sendImage(msg.to,path)
                        else:
                            ret_ = "「 Sticker Info 」"
                            ret_ += "\n~PRICE : "+soup.findAll('p', attrs={'class':'mdCMN08Price'})[0].text
                            ret_ += "\n~AUTHOR : "+soup.select("a[href*=/stickershop/author]")[0].text
                            ret_ += "\n~STICKER ID : {}".format(str(stk_id))
                            ret_ += "\n~STICKER PACKAGES ID : {}".format(str(pkg_id))
                            ret_ += "\n~STICKER VERSION : {}".format(str(stk_ver))
                            ret_ += "\n~STICKER URL : line://shop/detail/{}".format(str(pkg_id))
                            ret_ += "\n~DESCRIPTION :\n"+soup.findAll('p', attrs={'class':'mdCMN08Desc'})[0].text
                            samudra.sendMessage(msg.to, str(ret_))
                            query = int(stk_id)
                            if type(query) == int:
                               data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                               path = samudra.downloadFileURL(data)
                               samudra.sendImage(msg.to,path)
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    samudra.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = samudra.getContact(msg.contentMetadata["mid"])
                        path = samudra.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        samudra.sendMessage(msg.to," 「 Contact Info 」\n➸ Nama : " + msg.contentMetadata["displayName"] + "\n➸ MID : " + msg.contentMetadata["mid"] + "\n➸ Status Msg : " + contact.statusMessage + "\n➸ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        samudra.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = samudra.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = samudra.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            samudra.sendMessage(msg.to, "...")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  samudra.findAndAddContactsByMid(target)
                                  samudra.inviteIntoGroup(msg.to,[target])
                                  ryan = samudra.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  ""
                                  ret_ = "Ketik invite off jika Sudah Selesai"
                                  ry = str(ryan.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  samudra.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  samudra.sendMessage(msg.to,"🔄Anda terkena limit")
                                  wait["invite"] = False
                                  break
#ADD Bots
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        samudra.sendMessage(msg.to,"")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        samudra.sendMessage(msg.to,"Succes add Bost~")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        samudra.sendMessage(msg.to," Expelled")
                    else:
                        wait["dellbots"] = True
                        samudra.sendMessage(msg.to," Nothing from list")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        samudra.sendMessage(msg.to," Ready staff")
                        wait["addstaff"] = True
                    else:
                        staff[msg.contentMetadata["mid"]] = True
                        f=codecs.open('staff.json','w','utf-8')
                        json.dump(staff, f, sort_keys=True, indent=4,ensure_ascii=False)
                        wait["addstaff"] = True
                        samudra.sendMessage(msg.to,"Succes add to staff~")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        del staff[msg.contentMetadata["mid"]]
                        f=codecs.open('staff.json','w','utf-8')
                        json.dump(staff, f, sort_keys=True, indent=4,ensure_ascii=False)
                        samudra.sendMessage(msg.to,"Succes expell staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        samudra.sendMessage(msg.to,"Nothing in list staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        samudra.sendMessage(msg.to,"Ready in admin list")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        samudra.sendMessage(msg.to," Succes add to admin~")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        samudra.sendMessage(msg.to," Succes expell in admin list~")
                    else:
                        wait["delladmin"] = True
                        samudra.sendMessage(msg.to,"Nothing in admin list")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        samudra.sendMessage(msg.to," User ready in blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        samudra.sendMessage(msg.to,"Succes add blacklist user~")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        samudra.sendMessage(msg.to," Remove from blacklist user")
                    else:
                        wait["dblacklist"] = True
                        samudra.sendMessage(msg.to," Nothing in User blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        samudra.sendMessage(msg.to," Ready in User Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        samudra.sendMessage(msg.to," Succes add to Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        samudra.sendMessage(msg.to," Remove Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        samudra.sendMessage(msg.to," Ready in Talkban list")
#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in admin:
                    if wait["Addimage"]["status"] == True:
                        path = samudra.downloadObjectMsg(msg.id)
                        images[wait["Addimage"]["name"]] = str(path)
                        f = codecs.open("image.json","w","utf-8")
                        json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                        samudra.sendMessage(msg.to, " Berhasil menambahkan gambar {}".format(str(wait["Addimage"]["name"])))
                        wait["Addimage"]["status"] = False                
                        wait["Addimage"]["name"] = ""
               if msg.contentType == 2:
                 if msg._from in admin:
                    if wait["Addvideo"]["status"] == True:
                        path = samudra.downloadObjectMsg(msg.id)
                        videos[wait["Addvideo"]["name"]] = str(path)
                        f = codecs.open("video.json","w","utf-8")
                        json.dump(videos, f, sort_keys=True, indent=4, ensure_ascii=False)
                        samudra.sendMessage(msg.to, " Berhasil menambahkan video {}".format(str(wait["Addvideo"]["name"])))
                        wait["Addvideo"]["status"] = False                
                        wait["Addvideo"]["name"] = ""
               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["Addsticker"]["status"] == True:
                        stickers[wait["Addsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                        f = codecs.open("sticker.json","w","utf-8")
                        json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                        samudra.sendMessage(msg.to, " Berhasil menambahkan sticker {}".format(str(wait["Addsticker"]["name"])))
                        wait["Addsticker"]["status"] = False                
                        wait["Addsticker"]["name"] = ""
               
               if msg.contentType == 3:
                 if msg._from in admin:
                    if wait["Addaudio"]["status"] == True:
                        path = samudra.downloadObjectMsg(msg.id)
                        audios[wait["Addaudio"]["name"]] = str(path)
                        f = codecs.open("audio.json","w","utf-8")
                        json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                        samudra.sendMessage(msg.to, " Berhasil menambahkan mp3 {}".format(str(wait["Addaudio"]["name"])))
                        wait["Addaudio"]["status"] = False                
                        wait["Addaudio"]["name"] = ""
               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = samudra.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     samudra.updateGroupPicture(msg.to, path)
                     samudra.sendMessage(msg.to, "Succes Update Profile Group~")
               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["RAfoto"]:
                            path = samudra.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            samudra.updateProfilePicture(path)
                            samudra.sendMessage(msg.to,"Update Profile Succes~")
               if msg.contentType == 2:
                   if msg._from in admin:
                       if mid in Setmain["RAvideo"]:
                            path = samudra.downloadObjectMsg(msg_id)
                            Setmain["RAvideo"][mid]
                            samudra.updateProfileVideoPicture(path)
                            samudra.sendMessage(msg.to," Succes~")
          
               if msg.contentType == 1:
                 if msg._from in admin:
                        if Amid in Setmain["RAfoto"]:
                            path1 = samudra1.downloadObjectMsg(msg_id)
                            Setmain["RAfoto"][Amid]
                            samudra1.updateProfilePicture(path1)
                            samudra1.sendMessage(msg.to,"Succes change~")
                        elif Zmid in Setmain["RAfoto"]:
                            path11 = samudrajs.downloadObjectMsg(msg_id)
                            Setmain["RAfoto"][Zmid]
                            samudrajs.updateProfilePicture(path2)
                            samudrajs.sendMessage(msg.to,"Succes change~")                            
               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = samudra1.downloadObjectMsg(msg_id)
                     path2 = samudrajs.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     samudra1.updateProfilePicture(path1)
                     samudra1.sendMessage(msg.to, " Succes ~")
                     samudrajs.updateProfilePicture(path2)
                     samudrajs.sendMessage(msg.to, " Succes ~")
               if msg.contentType == 0:
                 if Setmain["autoRead"] == True:
                     samudra.sendChatChecked(msg.to, msg_id)
                     samudra1.sendChatChecked(msg.to, msg_id)
                 if text is None:
                     return
                 else:
                        for sticker in stickers:
                         #if msg._from in admin:
                           if text.lower() == sticker:
                              sid = stickers[text.lower()]["STKID"]
                              spkg = stickers[text.lower()]["STKPKGID"]
                              samudra.sendSticker(to, spkg, sid)
                        for image in images:
                         if msg._from in admin:
                           if text.lower() == image:
                              samudra.sendImage(msg.to, images[image])
                        for audio in audios:
                         if msg._from in admin:
                           if text.lower() == audio:
                              samudra.sendAudio(msg.to, audios[audio])
                        for video in videos:
                         if msg._from in admin:
                           if text.lower() == video:
                              samudra.sendVideo(msg.to, videos[video])
                        cmd = command(text)
                        
                        if cmd == "bot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                samudra.sendMessage(msg.to, " ➪ Selfbot diaktifkan")
                                
                        elif cmd == "bot off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                samudra.sendMessage(msg.to, " 🚫 Selfbot dinonaktifkan")
                                            
                        elif cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:  
                              helpK = helpkey()
                              samudra.sendMessage(msg.to, helpK)
                        elif cmd == "help1":
                          if wait["selfbot"] == True:
                            if msg._from in admin:  
                              helpK1 = helpadminset()
                              samudra.sendMessage(msg.to, helpK1)
                        elif cmd == "help2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:  
                              helpK2 = helpmedia()
                              samudra.sendMessage(msg.to, helpK2)
                        elif cmd == "help3":
                          if wait["selfbot"] == True:
                            if msg._from in admin:  
                              helpK3 = helpsetgroup()
                              samudra.sendMessage(msg.to, helpK3)
                        elif cmd == "help4":
                          if wait["selfbot"] == True:
                            if msg._from in admin:  
                              helpK4 = helpprotection()
                              samudra.sendMessage(msg.to, helpK4)
                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "    😡 My Setting 😡 \n"
                                if wait["chatbot"] == True: md+="😡 ✔ Auto Chat\n"
                                else: md+="😡 ❎  Auto Chat\n"
                                if wait["mentionKick"] == True: md+="😡 ✔ Respon Kick\n"
                                else: md+="😡 ❎ Respon Kick\n"
                                if wait["stickerOn"] == True: md+="😡 ✔ Check Sticker\n"
                                else: md+="😡 ❎ Check Sticker\n"
                                if wait["contact"] == True: md+="😡 ✔ Check Contact\n"
                                else: md+="😡 ❎ Check Contact\n"
                                if wait["talkban"] == True: md+="😡 ✔ Talkban「On」\n"
                                else: md+="😡 ❎ Talkban\n"
                                if wait["autoBlock"] == True: md+="😡 ✔ Auto Block\n"
                                else: md+="😡 ❎ Auto Block\n"
                                if wait["detectMention"] == True: md+="😡 ✔ Auto Respon\n"
                                else: md+="😡 ❎ Auto Respon\n"
                                if wait["Timeline"] == True: md+="😡 ✔ Detail Post\n"
                                else: md+="😡 ❎ Detail Post\n"
                                if wait["autoJoin"] == True: md+="😡 ✔ Auto Join\n"
                                else: md+="😡 ❎ Auto Join\n"
                                if wait["autoAdd"] == True: md+="😡 ✔ Auto Add\n"
                                else: md+="😡 ❎ Auto Add\n"
                                if settings["autoJoinTicket"] == True: md+="😡 ✔ Join Link\n"
                                else: md+="😡 ❎ Join Link\n"
                                if msg.to in welcome: md+="😡 ✔ Sambutan\n"
                                else: md+="😡 ❎ Sambutan\n"
                                if wait["autoLeave"] == True: md+="😡 ✔ Auto Leave\n"
                                else: md+="😡 ❎ Auto Leave\n"
                                if msg.to in proLink: md+="😡 ✔ Block Link\n"
                                else: md+="😡 ❎ Block Code Qr\n"
                                if msg.to in ghostJs: md+="😡 ✔ Block Js\n"
                                else: md+="😡 ❎ Block Js\n"
                                if msg.to in protectjoin: md+="😡 ✔ Block Join\n"
                                else: md+="😡 ❎ Block Join\n"
                                if msg.to in proKick: md+="😡 ✔ Block Kick\n"
                                else: md+="😡 ❎ Block Kick\n"
                                if msg.to in proInvite: md+="😡 ✔ Block Invite\n"
                                else: md+="😡 ❎ Block Invite\n"
                                if msg.to in proName: md+="?? ✔ Block Name\n"
                                else: md+="😡 ❎ Lock Name Group\n"
                                if msg.to in picon: md+="😡 ✔ Block Join\n"
                                else: md+="😡 ❎ Lock Icon Group\n"
                                if msg.to in protectantijs: md+="😡 ✔ Lock Js group\n"
                                else: md+="😡 ❎ Lock js Grouop\n"
                                if msg.to in proCancel: md+="😡 ✔ Block Cancel\n"
                                else: md+="😡 ❎ Lock Cancel\n"
                                samudra.sendMessage(msg.to, md+"\n↘Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"+"\n↘Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d'))
                                
                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in admin:
                                samudra.sendMessage(msg.to,"Ini creatornya: Samudra\n\nhttps://line.me/ti/p/~samudrabot.py") 
                                ma = ""
                                for i in creator:
                                    ma = samudra.getContact(i)
                                    samudra.sendMessage(msg.to, None, contentMetadata={'': i}, contentType=13)

                        elif cmd.startswith("joox"):
                            try:
                                proses = text.split(" ")
                                urutan = text.replace(proses[0] + " ","")
                                r = requests.get("http://api.zicor.ooo/joox.php?song={}".format(str(urllib.parse.quote(urutan))))
                                data = r.text
                                data = json.loads(data)
                                b = data
                                c = str(b["title"])
                                d = str(b["singer"])
                                e = str(b["url"])
                                g = str(b["image"])
                                hasil = "Penyanyi: "+str(d)
                                hasil += "\nJudul : "+str(c)
                                samudra.sendImageWithURL(to,g)
                                samudra.sendAudioWithURL(to,e)
                                samudra.sendMessage(msg.to,hasil)
                            except Exception as error:
                                samudra.sendMessage(to, "error\n" + str(error))
                                logError(error) 

                        elif cmd.startswith('about'):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                            try:
                                arr = []
                                today = datetime.today()
                                thn = 2018 
                                bln = 5     #isi bulannya yg sewa
                                hr = 17    #isi tanggalnya yg sewa
                                future = datetime(thn, bln, hr)
                                days = (str(future - today))
                                comma = days.find(",")
                                days = days[:comma]
                                contact = samudra.getContact(mid)
                                favoritelist = samudra.getFavoriteMids()
                                grouplist = samudra.getGroupIdsJoined()
                                contactlist = samudra.getAllContactIds()
                                blockedlist = samudra.getBlockedContactIds()
                                eltime = time.time() - mulai
                                bot = runtime(eltime)
                                start = time.time()
                                samudra.sendMessage("u32c842796ed032f17ab294504465daed", '.')
                                elapsed_time = time.time() - start
                                ryan = samudra.getContact(mid)
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "😡 Info Selfbot 😡\n😡 Name : "
                                ret_ = "😡 Group : {} Group".format(str(len(grouplist)))
                                ret_ += "\n• Friend : {} Friend".format(str(len(contactlist)))
                                ret_ += "\n• Blocked : {} Blocked".format(str(len(blockedlist)))
                                ret_ += "\n• Favorite : {} Favorite".format(str(len(favoritelist)))
                                ret_ += "\n• Version : Py3"
                                ret_ += "\n• Expired : {} - {} - {}".format(str(hr), str(bln), str(thn))
                                ret_ += "\n•In days : {} again".format(days)
                                ret_ += "\n 😡 Speed Respon 😡\n• {} detik".format(str(elapsed_time))
                                ret_ += "\n😡 Selfbot Runtime 😡\n• {}".format(str(bot))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                samudra.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                samudra.sendContact(to, "ucc01b1731756d032737550292e9eccee")
                            except Exception as e:
                                samudra.sendMessage(msg.to, str(e))

                        elif cmd == "me":
                           if wait["selfbot"] == True:
                             if msg._from in admin:
                                 samudra.sendMentionFooter(to, '[ User self ]\n', sender, "https://line.me/ti/p/nzHxNON2Ww", "http://dl.profile.line-cdn.net/"+cl.getContact(sender).pictureStatus, cl.getContact(sender).displayName);cl.sendMessage(to, cl.getContact(sender).displayName, contentMetadata = {'previewUrl': 'http://dl.profile.line-cdn.net/'+cl.getContact(sender).pictureStatus, 'i-installUrl': 'https://line.me/ti/p/nzHxNON2Ww', 'type': 'mt', 'subText': "Samudra_Bots", 'a-installUrl': 'https://line.me/ti/p/nzHxNON2Ww', 'a-installUrl': ' https://line.me/ti/p/nzHxNON2Ww', 'a-packageName': 'com.spotify.music', 'countryCode': 'ID', 'a-linkUri': 'https://line.me/ti/p/nzHxNON2Ww', 'i-linkUri': 'https://line.me/ti/p/nzHxNON2Ww', 'id': 'mt000000000a6b79f9', 'text': 'Samudra__Bots', 'linkUri': 'https://line.me/ti/p/nzHxNON2Ww'}, contentType=19)
                        elif text.lower() == "mid":
                               samudra.sendMessage(msg.to, msg._from)
                        elif cmd.startswith("mid "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = samudra.getContact(key1)
                               samudra.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               samudra.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif ("Steal " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = samudra.getContact(key1)
                               a = samudra.getProfileCoverURL(mid=key1)
                               samudra.sendMessage(msg.to, "「 Contact Info 」\n• Nama : "+str(mi.displayName)+"\n• Mid : " +key1+"\n• Status Msg"+str(mi.statusMessage))
                               samudra.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   samudra.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                                   samudra.sendImageWithURL(receiver, a)
                               else:
                                   samudra.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))
                                   samudra.sendImageWithURL(receiver, a)

                        elif ("Cover " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    u = key["MENTIONEES"][0]["M"]
                                    a = samudra.getProfileCoverURL(mid=u)
                                    samudra.sendImageWithURL(receiver, a)
                                except Exception as e:
                                    samudra.sendMessage(receiver, str(e))

                        elif ("Sticker: " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    query = msg.text.replace("Sticker: ", "")
                                    query = int(query)
                                    if type(query) == int:
                                        samudra.sendImageWithURL(receiver, 'https://stickershop.line-scdn.net/stickershop/v1/product/'+str(query)+'/ANDROID/main.png')
                                        samudra.sendMessage(receiver, 'https://line.me/S/sticker/'+str(query))
                                    else:
                                        samudra.sendMessage(receiver, 'gunakan key sticker angka bukan huruf')
                                except Exception as e:
                                    samudra.sendMessage(receiver, str(e))

                        elif "/ti/g/" in msg.text.lower():
                           if msg._from in admin:
                             if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                    if l not in n_links:
                                       n_links.append(l)
                                 for ticket_id in n_links:
                                    group = samudra.findGroupByTicket(ticket_id)
                                    samudra.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    samudra.sendMessage(msg.to, "~Joint : %s" % str(group.name))
                                    group1 = samudra1.findGroupByTicket(ticket_id)
                                    samudra1.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                    samudra1.sendMessage(msg.to, "~Joint : %s" % str(group.name))
                                    
                        elif cmd.startswith('woy'):
                          if wait["selfbot"] == True:
                            if msg._from in creator or msg._from in owner or msg._from in admin:
                                try:samudra.kickoutFromGroup(msg.to, ["u5d72909e8c37e0ab805952336f872361"]);wait["limitkick"] = False
                                except:wait["limitkick"] = True
                                md = ""
                                if wait["limitkick"]== True: md+="❎ Limite"
                                else: md+="😡✔ Sehat"
                                samudra.sendMessage(msg.to, md)
                                
                                try:samudra1.kickoutFromGroup(msg.to, ["u5d72909e8c37e0ab805952336f872361"]);wait["limitkick"] = False
                                except:wait["limitkick"] = True
                                
                                md = ""
                                if wait["limitkick"]== True: md+="❎ Limite"
                                else: md+="😡✔ Sehat"
                                samudra1.sendMessage(msg.to, md)
                                
                        elif cmd == "reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      samudra.rejectGroupInvitation(gid)
                                  samudra.sendMessage(to, "~ Berhasil tolak sebanyak {} undangan grup".format(str(len(ginvited))))
                              else:
                                  samudra.sendMessage(to, "~ Tidak ada undangan yang tertunda")
                                  
                        elif cmd.startswith("delfriend "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = samudra.getContact(ls)
                                    samudra.deleteContact(ls)
                                samudra.sendMessage(to, "Success Del " + str(contact.displayName) + " to Friendlist")
                        elif cmd.startswith("addfriend "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = samudra.getContact(ls)
                                    samudra.findAndAddContactsByMid(ls)
                                samudra.sendMessage(to, "Success Add " + str(contact.displayName) + " to Friendlist")
                        elif cmd.startswith("asisadd "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = samudra1.getContact(ls)
                                    samudra1.findAndAddContactsByMid(ls)
                                    samudra1.sendMessage(to, "Success")
                                
                                    contact = samudrajs.getContact(ls)
                                    samudrajs.findAndAddContactsByMid(ls)
                                    samudrajs.sendMessage(to, "Success")

                        elif text.lower() == "hapus chat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                               except:
                                   pass

                        elif text.lower() == "hapus mantan":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   samudra.removeAllMessages(op.param2)
                                   samudra.sendMessage(msg.to,"мᴀɴтᴀɴ ᴅιмusɴᴀнκᴀɴ~.")
                                   samudra1.removeAllMessages(op.param2)
                                   samudra1.sendMessage(msg.to,"Succes~.")
                                  # samudra2.sendMessage(msg.to,"Succes~.")                              
                               except:
                                   pass

                        elif cmd.startswith("bc: "):
                           if msg._from in admin:
                             sep = text.split(" ")
                             bc = text.replace(sep[0] + " ","")
                             saya = samudra.getGroupIdsJoined()
                             for group in saya:
                                ryan = samudra.getContact(mid)
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "◀Broadcast ▶\n↘By "
                                ret_ = "{}".format(str(bc))
                                ry = str(ryan.displayName)
                                pesan = '~'
                                pesan2 = pesan+"@x\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                samudra.sendMessage(group, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                             
                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               samudra.sendMessage(msg.to, "↘ " + str(Setmain["keyCommand"]) + " ")
                               
                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   samudra.sendMessage(msg.to, "🔄Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   samudra.sendMessage(msg.to, "↘Setkey diganti jadi「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               samudra.sendMessage(msg.to, " Setkey Anda telah direset")

                        elif cmd == "restart":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               samudra.sendMessage(to,"Waaiiit..... ⏳")
                               Setmain["restartPoint"] = msg.to
                               time.sleep(3)
                               samudra.sendMessage(to,"███▒▒▒▒▒▒▒")
                               time.sleep(2)
                               samudra.sendMessage(to,"█████▒▒▒▒▒")
                               time.sleep(2)
                               samudra.sendMessage(to,"██████████")
                               time.sleep(2)
                               samudra.sendMessage(to,"~Bots Actived..✔")
                               restartBot()
                               
                            
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                eltime = time.time() - mulai
                                bot = runtime(eltime)
                                ryan = samudra.getContact(mid)
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "↘User : "
                                ret_ = "• {}".format(str(bot))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                samudra.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = samudra.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                samudra.sendMessage(msg.to, "↘Group Info↖\n↘Nama Group : {}".format(G.name)+ "\n↘ID Group : {}".format(G.id)+ "\n↘Pembuat : {}".format(G.creator.displayName)+ "\n↘Waktu Dibuat : {}".format(str(timeCreated))+ "\n↘Jumlah Member : {}".format(str(len(G.members)))+ "\n↘Jumlah Pending : {}".format(gPending)+ "\n↘Group Qr : {}".format(gQr)+ "\n↘Group Ticket : {}".format(gTicket))
                                samudra.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                samudra.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                samudra.sendMessage(msg.to, str(e))

                        elif cmd == "invite":
                          if msg._from in admin:
                                wait['undang'] = True
                                samudra.sendMessage(to,"Send Contact For Invite Target")

                        elif cmd == "2invite":
                          if msg._from in admin:
                                wait['undang'] = True
                                samudra1.sendMessage(to,"Send Contact For Invite Target")

                        elif cmd == "groups":
                          if msg._from in admin:
                            groups = samudra.groups
                            ret_ = "「 Group List 」\n"
                            no = 0 + 1
                            for gid in groups:
                                group = samudra.getGroup(gid)
                                ret_ += "\n{}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no += 1
                            ret_ += "\n\n「 Total {} Groups 」".format(str(len(groups)))
                            samudra.sendMessage(to, str(ret_))
                         
                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += " ◀ Group Info ▶"
                                ret_ += "\n➥Nama Group : {}".format(G.name)
                                ret_ += "\n➥ID Group : {}".format(G.id)
                                ret_ += "\n➥Pembuat : {}".format(gCreator)
                                ret_ += "\n➥Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n➥Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n➥Jumlah Pending : {}".format(gPending)
                                ret_ += "\n➥Group Qr : {}".format(gQr)
                                ret_ += "\n➥Group Ticket : {}".format(gTicket)
                                ret_ += "\n➥Picture Url : http://dl.profile.line-cdn.net/{}".format(G.pictureStatus)
                                ret_ += ""
                                samudra.sendMessage(to, str(ret_))
                                samudra.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except:
                                pass
                            
                        elif cmd.startswith("joinall "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                G.preventedJoinByTicket = False
                                samudra.updateGroup(G)
                                invsend = 0
                                Ticket = samudra.reissueGroupTicket(group)
                                samudra1.acceptGroupInvitationByTicket(group,Ticket)
                                G.preventedJoinByTicket = True
                                samudra.updateGroup(G)
                                samudra.sendMessage(msg.to,"~Succes Joinall from~ Group \n"+str(G.name))
                            except:
                                pass

                        elif cmd.startswith("!leave "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = samudra.getGroup(group)
                            #samudra.sendMessage(msg.to, "Bots di paksa keluar oleh Owner")
                            try:
                                samudra.leaveGroup(group)
                                samudra.sendMessage(msg.to,"~Succes Leave from~ Group \n"+str(G.name))
                            except:
                                pass
                        elif cmd.startswith("ticket "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = samudra.getGroup(group)
                            try:
                                samudra.updateGroup(G)
                                gurl = samudra.reissueGroupTicket(group)
                                samudra.sendMessage(msg.to, "Group "+str(G.name)+ "\nLink nya : http://line.me/R/ti/g/"+gurl)
                            except:
                            	samudra.sendMessage(msg.to,"I no there")

                        elif cmd.startswith("2ticket "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudra1.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = samudra1.getGroup(group)
                            try:
                                samudra1.updateGroup(G)
                                gurl = samudra1.reissueGroupTicket(group)
                                samudra1.sendMessage(msg.to, "Group "+str(G.name)+ "\nLink nya : http://line.me/R/ti/g/"+gurl)
                            except:
                            	samudra1.sendMessage(msg.to,"I no there")


                        elif cmd.startswith("ticketjs1 "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudrajs.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = samudrajs.getGroup(group)
                            try:
                                samudrajs.updateGroup(G)
                                gurl = samudrajs.reissueGroupTicket(group)
                                samudrajs.sendMessage(msg.to, "Group "+str(G.name)+ "\nLink nya : http://line.me/R/ti/g/"+gurl)
                            except:
                            	samudrajs.sendMessage(msg.to,"I no there")
                                        
                        elif cmd.startswith("invitegid: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = samudra.getGroup(group)
                            if gid == "":
                                    samudra.sendMessage(msg.to,"Group id wrong")
                                    try:
                                        samudra.findAndAddContactsByMid(MID)
                                        samudra.inviteIntoGroup(gid,[MID])
                                    except:
                                    	pass
                        elif cmd.startswith("groupid: "):
                          if msg._from in owner or msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = samudra.getGroup(group)
                            gid = samudra.getGroup(to)
                            try:
                                samudra.sendMessage(to, "~"+str(G.name) + "\n" +gid.id)
                            except:
                            	pass     
                        elif cmd.startswith("leaveall "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = samudra.getGroup(group)
                            try:
                                samudra1.leaveGroup(group)
                                samudra.sendMessage(msg.to,"Succes leaveall from group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("1gurl "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = samudra1.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra1.getGroup(group)
                                G.preventedJoinByTicket = False
                                samudra1.updateGroup(G)
                                invsend = 0
                                Ticket = samudra1.reissueGroupTicket(group)
                                samudra.acceptGroupInvitationByTicket(group,Ticket)
                                G.preventedJoinByTicket = True
                                samudra1.updateGroup(G)
                                samudra.sendMessage(msg.to,"Succes join to group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("1open "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = samudra1.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra1.getGroup(group)
                                G.preventedJoinByTicket = False
                                samudra1.updateGroup(G)
                                samudra1.sendMessage(msg.to,"Succes Open Qr in group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("1jsopen "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = samudrajs.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudrajs.getGroup(group)
                                G.preventedJoinByTicket = False
                                samudrajs.updateGroup(G)
                                samudrajs.sendMessage(msg.to,"Succes Open Qr in group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("open "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                G.preventedJoinByTicket = False
                                samudra.updateGroup(G)
                                samudra.sendMessage(msg.to,"Succes Open Qr in group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd.startswith("close "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                G.preventedJoinByTicket = True
                                samudra.updateGroup(G)
                                samudra.sendMessage(msg.to,"Succes Close Qr in group~\n" + str(G.name))
                            except:
                                pass
                                
                        elif cmd == "gid":
                          if msg._from in admin:
                            if msg.toType != 2: return
                            gid = client.getGroup(to)
                            samudra.sendMessage(to, "" + gid.id)
              
                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "➥ "+ str(no) + ". " + mem.displayName
                                samudra.sendMessage(to,"~ Group Name : ◀ " + str(G.name) + " ▶\n\n   [ List Member ]\n" + ret_ + "\n\n[Total %i Members]" % len(G.members))
                            except: 
                                pass
                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra.getGroupIdsJoined()
                               for i in gid:
                                   G = samudra.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               samudra.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "glist1":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra1.getGroupIdsJoined()
                               for i in gid:
                                   G = samudra1.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               samudra1.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "glistjs1":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudrajs.getGroupIdsJoined()
                               for i in gid:
                                   G = samudrajs.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               samudrajs.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = samudra.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   samudra.updateGroup(X)
                                   samudra.sendMessage(msg.to, "➥Succes Open Code qr  ...")

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = samudra.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   samudra.updateGroup(X)
                                   samudra.sendMessage(msg.to, "➥Succes Closed Qr Code.....")
                                   
                        elif cmd == "link":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = samudra.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      samudra.updateGroup(x)
                                   gurl = samudra.reissueGroupTicket(msg.to)
                                   samudra.sendMessage(msg.to, "Grup "+str(x.name)+ "\nLink nya : http://line.me/R/ti/g/"+gurl)

#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                samudra.sendMessage(msg.to,"➥Kirim fotonya.....")

                        elif cmd == "updatebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                samudra.sendMessage(msg.to,"➥Kirim fotonya.....")
                                
                        elif cmd == "updatefoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                samudra.sendMessage(msg.to,"➥Kirim fotonya.....")

                        elif cmd == "cvp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAvideo"][mid] = True
                                samudra.sendMessage(msg.to,"➥Kirim videonya.....")
                                
                        elif cmd == "bot1up":
                            if msg._from in admin:
                                Setmain["RAfoto"][Amid] = True
                                samudra1.sendMessage(msg.to,"➥Kirim fotonya.....")
                        elif cmd == "update js":
                            if msg._from in admin:
                                Setmain["RAfoto"][Zmid] = True
                                samudrajs.sendMessage(msg.to,"➥Kirim fotonya.....")

                                
                        elif cmd.startswith("status "):
                          if msg._from in admin:
                            string = removeCmd("updatestatus", text)
                            if len(string) <= 10000000000:
                                pname = samudra.getContact(sender).statusMessage
                                profile = samudra.getProfile()
                                profile.statusMessage = string
                                samudra.updateProfile(profile)
                                #userid = "https://line.me/ti/p/~" + samudra.profile.userid
                                samudra.sendMessage(to ,"~Success")
                                
                                pname = samudra1.getContact(sender).statusMessage
                                profile = samudra1.getProfile()
                                profile.statusMessage = string
                                samudra1.updateProfile(profile)
                                #userid = "https://line.me/ti/p/~" + samudra1.profile.userid
                                samudra1.sendMessage(to, "~Success")
                                
                        elif cmd.startswith("name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudra.getProfile()
                                profile.displayName = string
                                samudra.updateProfile(profile)
                                samudra.sendMessage(msg.to,"➥Nama diganti jadi " + string + "")

                        elif cmd.startswith("name1: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudra1.getProfile()
                                profile.displayName = string
                                samudra1.updateProfile(profile)
                                samudra1.sendMessage(msg.to,"➥Nama diganti jadi " + string + "")
          
                        elif cmd.startswith("botname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                
                                profile = samudra1.getProfile()
                                profile.displayName = string
                                samudra1.updateProfile(profile)
                                samudra1.sendMessage(msg.to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith("namejs: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudrajs.getProfile()
                                profile.displayName = string
                                samudrajs.updateProfile(profile)
                                samudrajs.sendMessage(msg.to,"➥Nama diganti jadi " + string + "")
#===========BOT UPDATE============#     
                        elif msg.text.lower() in wait["tagall"]:
                          if msg._from in admin:        
                            if wait["selfbot"] == True:
                              if msg._from in owner or msg._from in admin or msg._from in staff:  
                                group = samudra.getGroup(msg.to)
                                nama = [contact.mid for contact in group.members]
                                k = len(nama)//20
                                for a in range(k+1):
                                    txt = u''
                                    s=0
                                    b=[]
                                    for i in group.members[a*20 : (a+1)*20]:
                                        b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                        s += 7
                                        txt += u'@Alin \n'
                                    samudra.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                                    samudra.sendMessage(to, "◀Mention {} Member▶".format(str(len(nama)))) 
                        elif cmd == "tag":
                          if msg._from in admin:        
                            if wait["selfbot"] == True:
                              if msg._from in owner or msg._from in admin or msg._from in staff:  
                                group = samudra.getGroup(msg.to)
                                nama = [contact.mid for contact in group.members]
                                k = len(nama)//20
                                for a in range(k+1):
                                    txt = u''
                                    s=0
                                    b=[]
                                    for i in group.members[a*20 : (a+1)*20]:
                                        b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                        s += 7
                                        txt += u'@Alin \n'
                                    samudra.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                                    samudra.sendMessage(to, "◀Mention {} Member▶".format(str(len(nama))))     
                                    
                        elif cmd.startswith("jsadd"):
                          if msg._from in admin:
                             try:
                                 samudrajs.findAndAddContactsByMid(mid)
                                 samudrajs.findAndAddContactsByMid(Amid)
                                 samudrajs.sendMessage(to, "Success")   
                             except:
                             	pass
                             
                        elif cmd.startswith("addbot"):
                          if msg._from in admin:
                             try:
                                 samudra.findAndAddContactsByMid(Amid)
                                 samudra.findAndAddContactsByMid(Zmid)
                                 cl.sendMessage(to, "Success")    
                           
                                 samudra1.findAndAddContactsByMid(mid)
                                 samudra1.findAndAddContactsByMid(Zmid)
                                 samudra1.sendMessage(to, "Success")              

                                 samudrajs.findAndAddContactsByMid(Amid)
                                 samudrajs.sendMessage(to, "Success")                   
                             except:
                                 pass

                        elif cmd == "list bot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +samudra.getContact(m_id).displayName + "\n"
                                samudra.sendMessage(msg.to," ◀ Daftar User Samudra__Bot ▶ \n\n"+ma+"\nTotal「%s」Bots" %(str(len(Bots))))

                        elif cmd == "list staff":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +samudra.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    a = a + 1
                                    end = '\n'
                                    mb += str(a) + ". " +samudra.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    a = a + 1
                                    end = '\n'
                                    mc += str(a) + ". " +samudra.getContact(m_id).displayName + "\n"
                                samudra.sendMessage(msg.to," ▰▰▰▰▰▰▰▰▰▰▰▰▰\n  ??🔰🔰 List Staff 🔰🔰🔰\n▰▰▰▰▰▰▰▰▰▰▰▰▰\n\n↘Owner:\n􀰂􀰂✦⇲͜͡௫͜͡✥Տɑʍմժɾɑ➠✦􏿿 \n↘Admin:\n"+mb+"\n↘Staff:\n"+mc+"\nTotal「%s」Staff or admin" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "list pro":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                me = ""
                                mf = ""
                                mg = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                e = 0
                                f = 0
                                g = 0
                                gid = proInvite
                                for group in gid:
                                    G = samudra.getGroup(group)
                                    a = a + 1
                                    end = "\n"
                                    ma += str(a) + ". " +G.name+ "\n"
                                gid = proLink
                                for group in gid:
                                    G = samudra.getGroup(group)
                                    b = b + 1
                                    end = "\n"
                                    mb += str(b) + ". " +G.name+ "\n"
                                gid = protectcancel
                                for group in gid:
                                    G = samudra.getGroup(group)
                                    c = c + 1
                                    end = "\n"
                                    mc += str(c) + ". " +G.name+ "\n"
                                gid = proKick
                                for group in gid:
                                    G = samudra.getGroup(group)
                                    d = d + 1
                                    end = "\n"
                                    md += str(d) + ". " +G.name+ "\n"
                                gid = proName
                                for group in gid:
                                    G = samudra.getGroup(group)
                                    e = e + 1
                                    end = "\n"
                                    me += str(e) + ". " +G.name+ "\n"    
                                gid = picon
                                for group in gid:
                                    G = samudra.getGroup(group)
                                    f = f + 1
                                    end = "\n"
                                    mf += str(f) + ". " +G.name+ "\n"       
                                gid = ghostJs
                                for group in gid:
                                    G = samudra.getGroup(group)
                                    g = g + 1
                                    end = "\n"
                                    mg += str(g) + ". " +G.name+ "\n"      
                                samudra.sendMessage(to,"▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n 🔰🔰🔰 List Protection 🔰🔰🔰\n▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n\nProtect invite:\n"+ma+"\nProtect link:\n"+mb+"\nProtect cancel:\n"+mc+"\nProtect members:\n"+md+"\nLock name:\n"+me+"\nLock Profile Group:\n"+mf+"\nLock Js:\n"+mg) 



                        elif "Rusuh" in msg.text:  
                           if msg._from in admin:
                            if msg.toType == 2:
                             #  print "Otw cleanse"
                               _name = msg.text.replace("Rusuh","")
                               gs = samudra1.getGroup(msg.to)
                               gs = samudrajs.getGroup(msg.to)
                               samudra1.sendMessage(msg.to,"ASSALAMUALAIKUM")
                               samudra1.sendMessage(msg.to,"Loha\n"
 "ASSALAMUALAIKUM\n"
"  ╭━Ⓓ✒Ⓡ✒ⒼⓄ✒Ⓝ✒\n"
"  ╰╮┏━┳┳┓┏┳┳┓┏┳┳┳┓\n"
"  ┏┻╋━┻┻┫┣┻┻┫┣┻┻┻┫\n"
"  ┃HLO▪┃KMI DTANG LGI┃\n"
"  ┗ⓞⓞ┻┻ⓞ━━ⓞ┻┻ⓞ━╯\n"
"UNTUK MENGGUSUR\nROOM KALIAN\n"
"..  (҂`_´)\n"
   " <,︻╦̵̵̿╤━ ҉     ~  •"
"█۞███████]▄▄▄▄▄▄▃●●\n"
"▂▄▅█████████▅▄▃▂…"
"[██████████████████]\n"
"◥⊙⊙▲⊙▲⊙▲⊙▲⊙▲⊙\n"
"╭━╮╭━╮\n"
"┃┃╰╯┃┃\n"
"┃╭╮╭╮┣┳━╮╭━━┳━━┳┳━╮\n"
"┃┃┃┃┃┣┫╭╮┫╭╮┃╭╮┣┫╭╯\n"
"┃┃┃┃┃┃┃┃┃┃╰╯┃╰╯┃┃┃\n"
"╰╯╰╯╰┻┻╯╰┻━╮┣━╮┣┻╯\n"
"╱╱╱╱╱╱╱╱╱╭━╯┣━╯┃\n"
"╱╱╱╱╱╱╱╱╱╰━━┻━━╯\n"
"👿━━━━━━━━━━━━━👿"
"Ⓣⓜⓟⓐ Ⓑⓐⓢⓐ_Ⓑⓐⓢⓘ\n"
"Ⓡⓐⓣⓐ ⓖⓐ ⓡⓐⓣⓐ\n" 
"Ⓨⓖ ⓟⓝⓣⓘⓝⓖ ⓚⓘⓑⓐⓡ\n"
"Ⓣⓐⓝⓖⓚⓘⓢ Ⓖⓞⓑⓛⓞⓚ\n"
"👿━━━━━━━━━━━━━👿\n"
	"╔══╗╔═╗╔══╗╔═╦═╗\n"
	"╚╗╔╝║╦╝║╔╗║║║║║║\n"
	"━║║━║╩╗║╠╣║║║║║║\n"
	"━╚╝━╚═╝╚╝╚╝╚╩═╩╝\n"
"👿━━━━━━━━━━━━━👿\n"
	"❀™SᎪmuᎠᏒᎪ_____BᎾᏆs™❀\n"
	"❀™SᎪmuᎠᏒᎪ_____BᎾᏆs™❀\n"
	"❀™SᎪmuᎠᏒᎪ_____BᎾᏆs™❀\n"
	"❀™SᎪmuᎠᏒᎪ_____BᎾᏆs™❀\n"
"👿━━━━━━━━━━━━━👿\n"        
"ⓈⒶⓂⓊⒹⓇⒶ ⒷⓄⓉⓈ\n"
"Ⓟⓤⓝⓨⓐ👿━━👿Ⓡⓐⓣⓐ Ⓝⓘ\n" 
"Ⓜⓐⓗ━👿━\n"
		"╔═╗╔══╗╔══╗╔══╗\n"
		"║╬║║╔╗║╚╗╔╝║╔╗║\n"
		"║╗╣║╠╣║━║║━║╠╣║\n"
		"╚╩╝╚╝╚╝━╚╝━╚╝╚╝\n"
		"━━━━━━━━━━━━━━━\n"
		"╔═╗╔══╗╔══╗╔══╗\n"
		"║╬║║╔╗║╚╗╔╝║╔╗║\n"
		"║╗╣║╠╣║━║║━║╠╣║\n"
		"╚╩╝╚╝╚╝━╚╝━╚╝╚╝\n"
		"━━━━━━━━━━━━━━━\n"
		"╔═╗╔══╗╔══╗╔══╗\n"
		"║╬║║╔╗║╚╗╔╝║╔╗║\n"
		"║╗╣║╠╣║━║║━║╠╣║\n"
		"╚╩╝╚╝╚╝━╚╝━╚╝╚╝\n"
		"━━━━━━━━━━━━━━━\n"
">>>Ⓑⓨⓔ_Ⓑⓨⓔ ⒼⒸ Ⓛⓐⓚⓝⓐⓣ>><\nⒹⓝⓓⓐⓜ Ⓒⓐⓡⓘ Ⓚⓜⓘ\n<<<<<<<<<>>\nhttps://line.me/ti/p/~samudrabots.py")
                               invitee = [contact.mid for contact in group.invitee]
                               targets = []
                               for g in gs.members:
                                   #if group.invitee is None or group.invitee == []:
                                   if _name in g.displayName:
                                       targets.append(g.mid)
                               if targets == []:
                                  samudra1.sendMessage(msg.to,"Sorry")
                              #    else:
                               for target in targets:
                                     if target not in Bots:
                                      try:
                                          kicker.cancelGroupInvitation(to, [inv])
                                          klist=[samudra1,samudrajs]
                                          kicker=random.choice(klist)
                                          kicker.kickoutFromGroup(msg.to,[target])
                                          print (msg.to,[g.mid])
                                      except:
                                          samudra1.sendMessage(msg.to,"I'm Sory")

                        elif cmd.startswith("eng:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=en&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                samudra.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)

                        elif cmd.startswith("indo:"):                                                    
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=in&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                samudra.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)

                        elif cmd.startswith("korea:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ko&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                samudra.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("japan:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ja&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                samudra.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("thai:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=th&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                samudra.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("arab:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ar&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                samudra.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)                    
                        elif cmd == "randomname":
                            r=requests.get("http://uinames.com/api/")
                            data=r.text
                            data=json.loads(data)
                            hasil = "Random Name :\n\n"
                            hasil += "Name: " + str(data["name"])                                              
                            hasil += "\nLastName: " + str(data["surname"])
                            hasil += "\nGender: " + str(data["gender"])
                            hasil += "\nCountry: " + str(data["region"])      
                            samudra.sendMessage(msg.id)
                            samudra.sendMessage(msg.to,str(hasil))
                        elif cmd.startswith("jawa:"):
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=jw&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                samudra.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)


 #============================================#
                              
                        elif cmd == "respon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                samudra1.sendMessage(msg.to,'✎﹏ѕαмυ∂яα__вσтѕ ѕтαу вσѕ﹏✍')

                        elif cmd == "mybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Musik(to, mid)
                                Musik(to, Amid)
                                Musik(to, Zmid)
                        
                        elif cmd == "ping":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                samudra1.sendMessage(msg.to,'[pong.😡!!]')
                
                        elif cmd == "joinqr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)
                                ginfo = samudra.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                samudra.updateGroup(G)
                                invsend = 0
                                Ticket = samudra.reissueGroupTicket(msg.to)
                                samudra1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = samudra1.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                #samudra1.updateGroup(G)


                        elif 'Projs ' in msg.text:                        
                           if msg._from in admin:
                              spl = msg.text.replace('Projs ','')
                              if spl == 'on':
                                  if msg.to in protectantijs:
                                       msgs = " ➪ Protect js sudah aktif"
                                  else:
                                       protectantijs.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = "Anti JS Diaktifkan\nDi Group : " +str(ginfo.name)
                                  samudra.sendMessage(msg.to, "ãDiaktifkanã\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Anti JS Dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = " ➪ Protect js Non Aktiff"
                                    samudra.sendMessage(msg.to, "ãDinonaktifkanã\n" + msgs)

                        elif cmd == "js stay":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                try:
                                    ginfo = samudra.getGroup(msg.to)
                                    samudra.inviteIntoGroup(msg.to, [Zmid])
                                    samudra.sendMessage(msg.to,"Projs stay udah siap")
                                except:
                                    pass

                        elif cmd == "joinbots":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = [Amid]
                                    samudra.inviteIntoGroup(msg.to, anggota)
                                    samudra1.acceptGroupInvitation(msg.to)
                                except:
                                    pass

                        elif cmd == "outbots":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)                                
                                samudra1.leaveGroup(msg.to)

                        elif cmd == "pamit":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)
                                samudra.sendMessage(msg.to, "Bye bye coy "+str(G.name))
                                samudra.leaveGroup(msg.to)

                        elif cmd == "1 in":
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)
                                ginfo = samudra.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                samudra.updateGroup(G)
                                invsend = 0
                                Ticket = samudra.reissueGroupTicket(msg.to)
                                samudra1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = samudra1.getGroup(msg.to)
                                G.preventedJoinByTicket = True

                        elif cmd == "js in":
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)
                                ginfo = samudra.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                samudra.updateGroup(G)
                                invsend = 0
                                Ticket = samudra.reissueGroupTicket(msg.to)
                                samudrajs.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = samudrajs.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                #samudrajs.updateGroup(G)

                        elif cmd == "js bye":
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                samudrajs.sendMessage(msg.to, "Bye bye fams "+str(G.name))
                                samudrajs.leaveGroup(msg.to)

                        elif cmd == "speedbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_group_time_start = time.time()
                                get_group = samudra.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                ssmudra.sendMessage(msg.to, "%.10f" % (get_group_time/3))
                                
                                get_group_time_start = time.time()
                                get_group = samudra1.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                samudra1.sendMessage(msg.to, "%.10f" % (get_group_time/3))

                        elif cmd == ".speed" or cmd == "speed":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               start = time.time()
                               samudra.sendMessage(msg.to," 🔀 Wifi Direct")
                               elapsed_time = time.time() - start
                               samudra.sendMessage(msg.to, "↘{} Perdetik".format(str(elapsed_time)))

                        elif cmd == "speed bot":
                            if msg._from in admin:
                                start = time.time()
                                samudra.sendMessage("ue1366ccbbcb5c453e943fcae08989fcd", '.')
                                elapsed_time = time.time() - start
                                samudra.sendMessage(msg.to, "%s" % (elapsed_time))
                                
                                start2 = time.time()
                                samudra.sendMessage("ue1366ccbbcb5c453e943fcae08989fcd", '.')
                                elapsed_time = time.time() - start2
                                samudra1.sendMessage(msg.to, "%s" % (elapsed_time))

                        elif cmd == "sider on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  #tz = pytz.timezone("Asia/Jakarta")
                                  #timeNow = datetime.now(tz=tz)
                                  #samudra.sendMessage(msg.to, " ↘ Status Sider ↖ \n ↘ Diaktifkan\n\n ↘ Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"+"\n ↘ Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d'))
                                  samudra.sendMessage(to,"Mode sider diaktivkan✔ By " + samudra.getContact(sender).displayName)
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "sider off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  samudra.sendMessage(to,"Mode sider dinonaktivkan✔ By " + samudra.getContact(sender).displayName)
                                  #samudra.sendMessage(msg.to, " ↘ Status Sider ↖ \n ↘ Di nonaktifkan\n\n ↘ Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"+"\n ↘ Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d'))
                              else:
                                  samudra.sendMessage(msg.to, " 🚫 Sudak tidak aktif")

#===================Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in owner or msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = " ➪ Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = ""
                                  samudra.sendMessage(to,"Welcome di aktifkan ✔ By " + samudra.getContact(sender).displayName)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = ""
                                    else:
                                         msgs = "➪ Sudah tidak aktif"
                                    samudra.sendMessage(to,"Non actived Welcome✔ By " + samudra.getContact(sender).displayName)

                        
                        elif 'Projoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Projoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = " ➪ Protect join sudah aktif"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = ""
                                  samudra.sendMessage(to,"Actived Projoin✔ By " + samudra.getContact(sender).displayName)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = ""
                                    else:
                                         msgs = " ➪ Protect join sudah tidak aktif"
                                    samudra.sendMessage(to,"Projoin Non Actived ✔ By " + samudra.getContact(sender).displayName)

                        elif 'Hard ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Hard ','')
                              if spl == 'on':
                                  if msg.to in ghostJs:
                                       msgs = " ➪ Protect hard sudah aktif"
                                  else:
                                       ghostJs.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = ""
                                  samudra.sendMessage(to,"Actived Prohard✔ By " + samudra.getContact(sender).displayName)
                              elif spl == 'off':
                                    if msg.to in ghostJs:
                                         ghostJs.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = ""
                                    else:
                                         msgs = " ➪ Protect hard sudah tidak aktif"
                                    samudra.sendMessage(to,"Projoin Non Actived ✔ By " + samudra.getContact(sender).displayName)

                        elif 'Prolink ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Prolink ','')
                              if spl == 'on':
                                  if msg.to in proLink:
                                       msgs = " ➪ Protect link sudah aktif"
                                  else:
                                       proLink.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = ""
                                  samudra.sendMessage(to,"Actived Prolink✔ By " + samudra.getContact(sender).displayName)
                              elif spl == 'off':
                                    if msg.to in proLink:
                                         proLink.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = ""
                                    else:
                                         msgs = " ➪ Protect link sudah tidak aktif"
                                    samudra.sendMessage(to,"Prolink Non Actived ✔ By " + samudra.getContact(sender).displayName)

                        elif 'Proinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Proinvite ','')
                              if spl == 'on':
                                  if msg.to in proInvite:
                                       msgs = " ➪ Protect invite sudah aktif"
                                  else:
                                       proInvite.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = ""
                                  samudra.sendMessage(to,"Actived Proinvite✔ By " + samudra.getContact(sender).displayName)
                              elif spl == 'off':
                                    if msg.to in proInvite:
                                         proInvite.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = ""
                                    else:
                                         msgs = " ➪ Protect inv sudah tidak aktif"
                                    samudra.sendMessage(to,"Proinv Non Actived ✔ By " + samudra.getContact(sender).displayName)
                                    
                        elif 'Prokick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Prokick ','')
                              if spl == 'on':
                                  if msg.to in proKick:
                                       msgs = " ➪ Protect kick sudah aktif"
                                  else:
                                       proKick.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = ""
                                  samudra.sendMessage(to,"Actived Prokick✔ By " + samudra.getContact(sender).displayName)
                              elif spl == 'off':
                                    if msg.to in proKick:
                                         proKick.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = ""
                                    else:
                                         msgs = " ➪ Protect kick sudah tidak aktif"
                                    samudra.sendMessage(to,"Prokick Non Actived ✔ By " + samudra.getContact(sender).displayName)

                        elif 'Procancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Procancel ','')
                              if spl == 'on':
                                  if msg.to in proCancel:
                                       msgs = " ➪ Protect cancel sudah aktif"
                                  else:
                                       proCancel.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = ""
                                  samudra.sendMessage(to,"Actived Procancel✔ By " + samudra.getContact(sender).displayName)
                              elif spl == 'off':
                                    if msg.to in proCancel:
                                         proCancel.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = ""
                                    else:
                                         msgs = " ➪ Protect cancel sudah tidak aktif"
                                    samudra.sendMessage(to,"Procancel Non Actived ✔ By " + samudra.getContact(sender).displayName)



                        elif cmd == "namelock:on" or text.lower() == 'proname on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.to in Memek["proName"] and msg.to in Memek["pro_name"]:
                                    samudra.sendMessage(to, "Namelock enabled🎵")
                                else:
                                    Memek["proName"][msg.to] = True
                                    Memek["pro_name"][msg.to] = cl.getGroup(msg.to).name
                                    f=codecs.open('protect.json','w','utf-8')
                                    json.dump(Memek, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    samudra.sendMessage(to,"Namelock set to on🎵")

                        elif cmd == "namelock:off" or text.lower() == 'proname off':
                          if wait["selfbot"] == True:
                            if msg._from in creator or msg._from in owner or msg._from in admin:
                                if msg.to not in Memek["proName"] and msg.to not in Memek["pro_name"]:
                                    samudra.sendMessage(to, "Namelock disable🎵")
                                else:
                                    Memek["proName"][msg.to] = True
                                    Memek["pro_name"][msg.to] = samudra.getGroup(msg.to).name
                                    f=codecs.open('protect.json','w','utf-8')
                                    json.dump(Memek, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    samudra.sendMessage(to,"Namelock set to on🎵")
                                                      
                        elif cmd == "iconlock:off" or text.lower() == 'iconlock off':
                          if wait["selfbot"] == True:
                            if msg._from in creator or msg._from in owner or msg._from in admin:
                                if msg.to not in Memek["picon"]:
                                    samudra.sendMessage(to,"Iconlock disabled🎵")
                                else:
                                    del Memek["picon"][msg.to]
                                    f=codecs.open('protect.json','w','utf-8')
                                    json.dump(Memek, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    samudra.sendMessage(to,"Iconlock set to off 🎵")            
                                                   
                        elif cmd == "icon lock" or text.lower() == 'iconlock on':
                          if wait["selfbot"] == True:
                            if msg._from in creator or msg._from in owner or msg._from in admin:
                                if msg.to in Memek["picon"]:
                                    samudra.sendMessage(to,"Iconlock enabled🎵")
                                else:
                                    Memek["picon"][msg.to] = True
                                    f=codecs.open('protect.json','w','utf-8')
                                    json.dump(Memek, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    samudra.sendMessage(to,"Iconlock set to on🎵")

                        elif 'Proall ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Proall ','')
                              if spl == 'on':
                                  if msg.to in proLink:
                                       msgs = ""
                                  else:
                                       proLink.append(msg.to)
                                  if msg.to in protectantijs:
                                       msgs = ""
                                  else:
                                       protectantijs.append(msg.to)
                                  if msg.to in ghostJs:
                                       msgs = ""
                                  else:
                                       ghostJs.append(msg.to)
                                  if msg.to in proKick:
                                      msgs = ""
                                  else:
                                      proKick.append(msg.to)
                                  if msg.to in proInvite:
                                      msgs = ""
                                  else:
                                      proInvite.append(msg.to)
                                  if msg.to in proCancel:
                                      ginfo = samudra.getGroup(msg.to)
                                      msgs = "Status : [ ON ]\nDi Group : " +str(ginfo.name)
                                      msgs += "\nSemua sudah diaktifkan"
                                  else:
                                      proCancel.append(msg.to)
                                      ginfo = samudra.getGroup(msg.to)
                                      msgs = "Status : [ ON ]\nDi Group : " +str(ginfo.name)
                                      msgs += "\nSemua protection diaktifkan"
                                  samudra.sendMessage(msg.to, "「 Status Protection 」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in proLink:
                                         proLink.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in ghostJs:
                                         ghostJs.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in proKick:
                                         proKick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in proInvite:
                                         proInvite.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in proCancel:
                                         proCancel.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Status : [ OFF ]\nDi Group : " +str(ginfo.name)
                                         msgs += "\nSemua protection dimatikan"
                                    else:
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Status : [ OFF ]\nDi Group : " +str(ginfo.name)
                                         msgs += "\nSemua protection dimatikan"
                                    samudra.sendMessage(msg.to, "「 Status Protection 」\n" + msgs)

                        elif cmd == "pro:all on" or text.lower() == 'max on':
                          if wait["selfbot"] == True:
                            if msg._from in creator or msg._from in owner or msg._from in admin:
                              if msg.to in Memek["proInvite"] or msg.to in Memek["proLink"] or msg.to in Memek["protectcancel"] or msg.to in Memek["proKick"] or msg.to in Memek["proName"] or msg.to in Memek["ghostJs"]:
                                  samudea.sendMessage(to,"Actived Set All Protection✔ By " + samudra.getContact(sender).displayName)
                              else:
                                  Memek["proInvite"][msg.to] = True
                                  Memek["proLink"][msg.to] = True
                                  Memek["protectcancel"][msg.to] = True
                                  Memek["ghostJs"][msg.to] = True
                                  Memek["proKick"][msg.to] = True
                                  Memek["proName"][msg.to] = True
                                  Memek["pro_name"][msg.to] = cl.getGroup(msg.to).name
                                  Memek["picon"][msg.to] = True
                                  #Memek["protectantijs"][msg.to] = True
                                  f=codecs.open('Memek.json','w','utf-8')
                                  json.dump(Memek, f, sort_keys=True, indent=4,ensure_ascii=False)
                                  samudra.sendMessage(to,"Actived ✔ By " + samudra.getContact(sender).displayName)
#===========KICKOUT============#
                        elif "Dupak " in msg.text:
                            if msg._from in admin:                                                                                                                                       
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]                                                                                                                                
                                targets = []
                                for x in key["MENTIONEES"]:                                                                                                                                  
                                    targets.append(x["M"])
                                for target in targets:                                                                                                                                       
                                    try:
                                        samudra.kickoutFromGroup(msg.to,[target])
                                        samudra.inviteIntoGroup(msg.to,[target])
                                        samudra.cancelGroupInvitation(msg.to,[target])
                                    except:
                                        pass
            
#===========ADMIN ADD============#
                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           samudra.sendMessage(to,"Add Admin ✔ By " + samudra.getContact(sender).displayName)
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff[target] = True
                                           f=codecs.open('staff.json','w','utf-8')
                                           json.dump(staff, f, sort_keys=True, indent=4,ensure_ascii=False)
                                           samudra.sendMessage(to,"Add Staff ✔ By " + samudra.getContact(sender).displayName)
                                       except:
                                           pass

                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.remove(target)
                                           samudra.sendMessage(to,"Admin Expelled ✔ By " + samudra.getContact(sender).displayName)
                                       except:
                                           pass

                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del staff[target]
                                           f=codecs.open('staff.json','w','utf-8')
                                           json.dump(staff, f, sort_keys=True, indent=4,ensure_ascii=False)
                                           samudra.sendMessage(to,"Staff Expelled ✔ By " + samudra.getContact(sender).displayName)
                                       except:
                                           pass

                        elif cmd == "refresh":
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                Setmain["RAfoto"] = False
                                settings["changePicture"] = False
                                samudra.sendMessage(msg.to," ✔ Aborting from bots ♩")

                        elif cmd == "my crit" or text.lower() == 'my crot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = samudra.getContact(i)
                                    samudra.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                                    samudra1.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "unsend on" or text.lower() == 'unsend on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["cekUnsend"] = True
                                sendMention(msg.to, sender, "User ", "\n ✔ Silahkan unsend pesannya,\nKetik unsend off jika sudah slesai")

                        elif cmd == "unsend off" or text.lower() == 'unsend off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["cekUnsend"] = False
                                sendMention(msg.to, sender, "User ", " \n 🚫 Deteksi unsend dinonaktifkan")
                                
                        elif cmd == "timeline on" or text.lower() == 'timeline on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Timeline"] = True
                                samudra.sendMessage(msg.to," ✔ Check Timeline actived ")

                        elif cmd == "timeline off" or text.lower() == 'timeline off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Timeline"] = False
                                samudra.sendMessage(msg.to," 🚫 Check Timeline Nonactived ")
                                
                        elif cmd == "invite on" or text.lower() == 'invite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                samudra.sendMessage(msg.to," ✔ Invte by Contact actived ")

                        elif cmd == "invite off" or text.lower() == 'invite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                samudra.sendMessage(msg.to,"🚫 Nonactived ")
                                
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["mentionKick"] = True
                                samudra.sendMessage(msg.to,"✔ Responkick Actived")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["mentionKick"] = False
                                samudra.sendMessage(msg.to,"🚫Nonactived")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                samudra.sendMessage(msg.to," ✔ Check Contact actived ")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                samudra.sendMessage(msg.to,"?? Deteksi contact dinonaktifkan")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                samudra.sendMessage(msg.to,"✔Auto respon actived")

                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                samudra.sendMessage(msg.to,"🚫 Auto respon dinonaktifkan")

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoin"] = True
                                samudra.sendMessage(msg.to,"✔ Autojoin actived")

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoin"] = False
                                samudra.sendMessage(msg.to,"🚫 Autojoin telah dinonaktifkan")
                                
                        elif cmd == "autoread off" or text.lower() == 'auto read off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = False
                                samudra.sendMessage(msg.to," 🚫 AutoRead telah dinonaktifkan")

                        elif cmd == "autoread on" or text.lower() == 'auto read on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = True
                                samudra.sendMessage(msg.to,"  ✔ AutoRead telah diaktifkan")
                                
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                samudra.sendMessage(msg.to," ✔ Autoleave telah diaktifkan")
                                
                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                samudra.sendMessage(msg.to,"🚫 Autoleave Nonactived")
                                
                        elif cmd == "autoblock on" or text.lower() == 'block on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                samudra.sendMessage(msg.to," ✔Autoblock Actived.....")

                        elif cmd == "autoblock off" or text.lower() == 'block off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                samudra.sendMessage(msg.to," 🚫  Non Actived.....")                                
                        elif cmd == "autolike on" or text.lower() == 'like on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeOn"] = True
                                samudra.sendMessage(msg.to," ✔ Autoalike Actived")
                        elif cmd == "autolike off" or text.lower() == 'like off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeOn"] = False
                                samudra.sendMessage(msg.to," ✔ Autolike Nonactived")
                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                samudra.sendMessage(msg.to,"✔ Autoadd telah diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                samudra.sendMessage(msg.to,"🚫 Autoadd telah dinonaktifkan")

                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["stickerOn"] = True
                                samudra.sendMessage(msg.to," ✔ Check Sticker actived ")

                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["stickerOn"] = False
                                samudra.sendMessage(msg.to," 🚫 Sticker check dinonaktifkan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = True
                                sendMention(msg.to, sender, " User ", "\n➪ Silahkan kirim link grupnya")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = False
                                samudra.sendMessage(msg.to," 🚫 Jointicket telah dinonaktifkan")
#============Chatbots================#
                        elif cmd == "chatbot on" or text.lower() == 'chatbots on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["chatbot"] = True
                                samudra.sendMessage(msg.to,"✔ AutoChat Actived")
                                
                        elif cmd == "chatbot off" or text.lower() == 'chatbots off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["chatbot"] = False
                                sdmudra.sendMessage(msg.to," ↘ AutoChat 🚫 nonaktived")
                        
                        elif cmd == 'sepi':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"Hooh gara2 kk sih gak mandi (¬_¬)")
                               
                        elif cmd == 'naik':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"Moh ah takut di modusin (¬_¬)")

                        elif cmd == 'nah':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"Nah neh noh ¯\_(ツ)_/¯ ")                               
                               
                        elif cmd == 'siang':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"Iya kk Mat siang mat aktivitas (￣へ￣)") 

                        elif cmd == 'malam':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"Iya malam k waktunya bikin ╮(╯▽╰)╭")
                               
                        elif cmd == 'sp':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to," 🔀 Internet gratisan ¯\_(ツ)_/¯")
                               samudra.sendMessage(to,"↘0.005076800537109375 Perdetik")
                               
                        elif cmd == 'assalamualaikum':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to," Waalaikumsalam ")
                               samudra.sendMessage(to,"Σ(O_O；)")

                        elif cmd == 'waalaikumsalam':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to," Moga yg jwb salam jodoh nya banyak ")
                               samudra.sendMessage(to,"╮(╯▽╰)╭ ")

                        elif cmd == 'typo':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to," Tenggelamkan ae yg Typo¯\_(ツ)_/¯")
                               samudra.sendMessage(to,"hehehe")                               
                             
                        elif cmd == 'kuy':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to," Kemana k ¯\_(ツ)_/¯")
       
                        elif cmd == 'pagi':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"Pagi juga kk Mandi gih biar gak jones terus ヽ(｀⌒´)ノ")
                               
                        elif cmd == 'halo':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"Halo juga kk apa kabar ?Σ(⊙▽⊙) ")
       
                        elif cmd == 'me':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"ma me ma me ae memek -_-")       
                               
                        elif cmd == 'oke':
                            if wait["chatbot"] == True:
                               samudra.sendMessage(to,"Oke aja deh gue daripada bonyok (╥_╥)")
#===========COMMAND BLACKLIST============#

                        elif cmd == "blc" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    samudra.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = samudra.getContact(i)
                                        samudra.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "ampuni" or cmd == "maafin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              samudra.sendMessage(msg.to,"↘Di Ampuni~ {} ~Tersangka.".format(str(len(wait["blacklist"]))))
                              wait["blacklist"] = {}                               
#===========COMMAND SET TEXT============#
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "➪Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  samudra.sendMessage(msg.to, "➪Pesan Msg diganti jadi :\n\n{}".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, " ➪Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  samudra.sendMessage(msg.to, "➪Welcome Msg diganti jadi :\n\n{}".format(str(spl)))

                        elif 'Set leave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set leave: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "➪Gagal mengganti Leave Msg")
                              else:
                                  wait["leave"] = spl
                                  samudra.sendMessage(msg.to, "➪Leave Msg diganti jadi :\n\n{}".format(str(spl)))

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "➪Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  samudra.sendMessage(msg.to, "➪ Respon Msg diganti jadi :\n\n{}".format(str(spl)))
                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  samudra.sendMessage(msg.to, "➪Sider Msg diganti jadi :\n\n{}".format(str(spl)))
                                  
                        elif 'Set mention: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set mention: ','')
                              if spl in [""," ","\n",None]:
                                  ssmudra.sendMessage(msg.to, "Gagal mengganti Key mention all member")
                              else:
                                  wait["tagall"] = spl
                                  samudra.sendMessage(msg.to, "key mention member ~ :\n\n{}".format(str(spl)))
 
#==================#  
                        elif cmd == "cancelall":
                          if msg._from in admin:
                            if msg.toType == 2:
                                group = samudra.getGroup(to)
                                if group.invitee is None or group.invitee == []:
                                    samudra.sendMessage(to, "Nothing")
                                else:
                                    invitee = [contact.mid for contact in group.invitee]
                                    for inv in invitee:
                                        samudra.cancelGroupInvitation(to, [inv])
                                        time.sleep(1)
                                    samudra.sendMessage(to, "Canceled {} user".format(str(len(invitee))))
                        elif cmd == "nukeall":
                          if msg._from in admin:
                            if msg.toType == 2:
                                group = samudra.getGroup(to)
                                gMembers = [contact.mid for contact in group.members]
                                for i in gMembers:
                                    time.sleep(0.008)
                                    samudra.kickoutFromGroup(to,[i])
                                samudra.sendMessage(to,"Casual Cleasing")
                            else:
                                samudra.sendMessage(to,"failed >_<")
               
                        elif text.lower() == '!sapu':
                            if msg._from in admin:
                               if msg.toType == 2:
                                  print ("[ 19 ] KICK ALL MEMBER")
                                  _name = msg.text.replace("!sapu","")
                                  gs = samudra.getGroup(msg.to)
    #                            ririn.sendMessage(msg.to,"「 Bye All 」")
    #                            ririn.sendMessage(msg.to,"「 Sory guys 」")
                                  targets = []
                                  for g in gs.members:
                                      if _name in g.displayName:
                                          targets.append(g.mid)
                                  if targets == []:
                                      samudra.sendMessage(msg.to,"Not Found")
                                  else:
                                      for target in targets:
                                          if not target in Bots:
                                              if not target in staff:
                                                  if not target in admin:
                                                      try:
                                                          klist=[samudra,samudra1]
                                                          kicker=random.choice(klist)
                                                          kicker.kickoutFromGroup(msg.to,[target])
                                                          print (msg.to,[g.mid])
                                                      except:
                                                          samudra.sendMessage(msg.to,"")                               

    except Exception as error:
        print (error)
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                oepoll.setRevision(op.revision)
                thread = threading.Thread(target=bot, args=(op,))
                thread.start()
    except Exception as e:
        print(e)
#==============Samudra Bots===========#
print ("============[Login Bot Samudra Sukses]==========")
thread1 = threading.Thread(target=bot1run)
thread2 = threading.Thread(target=bot2run)
thread3 = threading.Thread(target=bot3run)
thread4 = threading.Thread(target=bot4run)
thread1.start()
thread2.start()
thread3.start()
thread4.start()









